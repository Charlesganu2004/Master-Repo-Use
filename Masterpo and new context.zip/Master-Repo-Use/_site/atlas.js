'use strict';

const ATLAS_META = Object.freeze({
  release: 'V7',
  componentCount: 52,
  laneCount: 16,
  canvasCount: 12,
  routeCount: 36
});

const SVG_NS = 'http://www.w3.org/2000/svg';
const KIND_COLORS = {
  instruction: '#ff7a3d',
  capability: '#52d9ff',
  knowledge: '#c5a6ff',
  compute: '#79e7b7',
  control: '#f5d66c',
  delivery: '#ff777d'
};

const LANE_DEFINITIONS = [
  { id: 'intake', name: 'Intake', kind: 'instruction' },
  { id: 'surfaces', name: 'Client surfaces', kind: 'capability' },
  { id: 'identity', name: 'Identity', kind: 'control' },
  { id: 'instructions', name: 'Instruction layer', kind: 'instruction' },
  { id: 'skills', name: 'Skills', kind: 'capability' },
  { id: 'connectors', name: 'Connectors', kind: 'capability' },
  { id: 'knowledge', name: 'Knowledge', kind: 'knowledge' },
  { id: 'retrieval', name: 'Retrieval', kind: 'knowledge' },
  { id: 'validation', name: 'Validation', kind: 'control' },
  { id: 'routing', name: 'Routing', kind: 'control' },
  { id: 'local', name: 'Local models', kind: 'compute' },
  { id: 'hosted', name: 'Hosted models', kind: 'compute' },
  { id: 'hybrid', name: 'Hybrid control', kind: 'control' },
  { id: 'observe', name: 'Observability', kind: 'knowledge' },
  { id: 'governance', name: 'Governance', kind: 'control' },
  { id: 'delivery', name: 'Delivery', kind: 'delivery' }
];

const COMPONENT_DEFINITIONS = [
  { id: 'task', name: 'Task intake', lane: 'intake', x: 245, kind: 'instruction', detail: 'Normalizes the request and starts the system trace.', cmd: { windows: 'python scripts/catalog_guardian.py --help', macos: 'python3 scripts/catalog_guardian.py --help', linux: 'python3 scripts/catalog_guardian.py --help' } },
  { id: 'scope', name: 'Scope resolver', lane: 'intake', x: 610, kind: 'control', detail: 'Identifies the smallest safe set of resources for the task.' },
  { id: 'intent', name: 'Intent signal', lane: 'intake', x: 975, kind: 'instruction', detail: 'Classifies the desired outcome and interaction mode.' },
  { id: 'codex', name: 'Codex', lane: 'surfaces', x: 220, kind: 'capability', detail: 'Repository aware coding and system work surface.' },
  { id: 'copilot', name: 'Copilot', lane: 'surfaces', x: 505, kind: 'capability', detail: 'Native GitHub assistant surface.' },
  { id: 'claude', name: 'Claude', lane: 'surfaces', x: 790, kind: 'capability', detail: 'General agent and coding surface.' },
  { id: 'gemini', name: 'Gemini', lane: 'surfaces', x: 1075, kind: 'capability', detail: 'Multimodal and hosted model surface.' },
  { id: 'clone', name: 'Clone client', lane: 'surfaces', x: 1360, kind: 'capability', detail: 'Any compatible local or hosted client adapter.' },
  { id: 'workspace', name: 'Workspace trust', lane: 'identity', x: 300, kind: 'control', detail: 'Binds access to the active repository and workspace.' },
  { id: 'profile', name: 'User profile', lane: 'identity', x: 720, kind: 'control', detail: 'Applies local preferences without exposing secrets.' },
  { id: 'policy', name: 'Access policy', lane: 'identity', x: 1140, kind: 'control', detail: 'Enforces tool and filesystem permission boundaries.' },
  { id: 'agents', name: 'Agent contract', lane: 'instructions', x: 250, kind: 'instruction', detail: 'Loads repository behavior and safety rules.' },
  { id: 'setup', name: 'Setup guide', lane: 'instructions', x: 600, kind: 'instruction', detail: 'Routes the user toward client specific setup.' },
  { id: 'prompt', name: 'Prompt layer', lane: 'instructions', x: 950, kind: 'instruction', detail: 'Shapes task context and instruction priority.' },
  { id: 'budget', name: 'Token budget', lane: 'instructions', x: 1300, kind: 'instruction', detail: 'Keeps context and hosted model spend bounded.' },
  { id: 'skills', name: 'Skill registry', lane: 'skills', x: 260, kind: 'capability', detail: 'Selects task specific instruction packages.' },
  { id: 'plugins', name: 'Plugin bridge', lane: 'skills', x: 650, kind: 'capability', detail: 'Provides packaged skills, tools, and app connections.' },
  { id: 'skilltests', name: 'Skill quality', lane: 'skills', x: 1040, kind: 'control', detail: 'Checks scope, clarity, and expected behavior.' },
  { id: 'githubmcp', name: 'GitHub MCP', lane: 'connectors', x: 230, kind: 'capability', detail: 'Connects repository and issue workflows.' },
  { id: 'context7', name: 'Context lookup', lane: 'connectors', x: 540, kind: 'capability', detail: 'Retrieves current technical documentation.' },
  { id: 'browser', name: 'Browser control', lane: 'connectors', x: 850, kind: 'capability', detail: 'Tests and inspects interactive web surfaces.' },
  { id: 'apphub', name: 'App connector hub', lane: 'connectors', x: 1160, kind: 'capability', detail: 'Routes account backed tools with scoped access.' },
  { id: 'catalog', name: 'Repo catalog', lane: 'knowledge', x: 250, kind: 'knowledge', detail: 'Indexes vetted resources by task lane.' },
  { id: 'docs', name: 'Docs index', lane: 'knowledge', x: 610, kind: 'knowledge', detail: 'Finds canonical repository guidance.' },
  { id: 'history', name: 'Decision history', lane: 'knowledge', x: 970, kind: 'knowledge', detail: 'Keeps prior design and architecture context accessible.' },
  { id: 'chunks', name: 'Context chunks', lane: 'retrieval', x: 260, kind: 'knowledge', detail: 'Retrieves only the relevant source fragments.' },
  { id: 'vector', name: 'Vector cache', lane: 'retrieval', x: 610, kind: 'knowledge', detail: 'Stores reusable semantic retrieval signals.' },
  { id: 'rerank', name: 'Evidence reranker', lane: 'retrieval', x: 960, kind: 'knowledge', detail: 'Prioritizes the most relevant verified context.' },
  { id: 'validators', name: 'Static validators', lane: 'validation', x: 235, kind: 'control', detail: 'Runs deterministic policy and syntax checks.' },
  { id: 'schema', name: 'Schema check', lane: 'validation', x: 555, kind: 'control', detail: 'Verifies public and internal data contracts.' },
  { id: 'quality', name: 'Quality gate', lane: 'validation', x: 875, kind: 'control', detail: 'Combines tests, review, and experiential checks.' },
  { id: 'privacy', name: 'Privacy gate', lane: 'validation', x: 1195, kind: 'control', detail: 'Blocks repository level data from public artifacts.' },
  { id: 'router', name: 'Hybrid router', lane: 'routing', x: 310, kind: 'control', detail: 'Selects local, hosted, or split execution.' },
  { id: 'routepolicy', name: 'Route policy', lane: 'routing', x: 720, kind: 'control', detail: 'Balances quality, latency, privacy, and cost.' },
  { id: 'fallback', name: 'Fallback graph', lane: 'routing', x: 1130, kind: 'control', detail: 'Defines recovery when a model or tool is unavailable.' },
  { id: 'tiny', name: 'Tiny local', lane: 'local', x: 230, kind: 'compute', detail: 'Fast extraction and classification on constrained hardware.' },
  { id: 'small', name: 'Small local', lane: 'local', x: 530, kind: 'compute', detail: 'Everyday summaries, edits, and structured work.' },
  { id: 'mid', name: 'Mid local', lane: 'local', x: 830, kind: 'compute', detail: 'Practical coding and deeper local reasoning.' },
  { id: 'large', name: 'Large local', lane: 'local', x: 1130, kind: 'compute', detail: 'High capability local work on strong hardware.' },
  { id: 'hostfast', name: 'Hosted fast', lane: 'hosted', x: 330, kind: 'compute', detail: 'Low latency hosted completion for burst demand.' },
  { id: 'hostbalanced', name: 'Hosted balanced', lane: 'hosted', x: 720, kind: 'compute', detail: 'General hosted reasoning with balanced cost.' },
  { id: 'hostdeep', name: 'Hosted deep', lane: 'hosted', x: 1110, kind: 'compute', detail: 'High depth reasoning for complex, verified work.' },
  { id: 'localfirst', name: 'Local first', lane: 'hybrid', x: 245, kind: 'control', detail: 'Keeps eligible tasks on the user machine.' },
  { id: 'splitwork', name: 'Split workload', lane: 'hybrid', x: 565, kind: 'control', detail: 'Divides retrieval, generation, and validation.' },
  { id: 'verifyroute', name: 'Verify then lift', lane: 'hybrid', x: 885, kind: 'control', detail: 'Escalates only after local validation finds uncertainty.' },
  { id: 'budgetroute', name: 'Budget governor', lane: 'hybrid', x: 1205, kind: 'control', detail: 'Limits hosted calls to the highest value steps.' },
  { id: 'telemetry', name: 'Route telemetry', lane: 'observe', x: 285, kind: 'knowledge', detail: 'Records aggregate path performance.' },
  { id: 'costmeter', name: 'Cost meter', lane: 'observe', x: 695, kind: 'knowledge', detail: 'Tracks model and tool cost signals.' },
  { id: 'trace', name: 'Trace explorer', lane: 'observe', x: 1105, kind: 'knowledge', detail: 'Makes the complete route inspectable.' },
  { id: 'guardian', name: 'Catalog guardian', lane: 'governance', x: 280, kind: 'control', detail: 'Applies lifecycle and maintenance policy.' },
  { id: 'security', name: 'Security scan', lane: 'governance', x: 690, kind: 'control', detail: 'Runs safe static intake and repository checks.' },
  { id: 'release', name: 'Public delivery', lane: 'delivery', x: 480, kind: 'delivery', detail: 'Builds the privacy safe site and release artifact.', cmd: { windows: 'python scripts/build_public_site.py', macos: 'python3 scripts/build_public_site.py', linux: 'python3 scripts/build_public_site.py' } }
];

const CANVAS_DEFINITIONS = [
  { id: 'atlas', name: 'Full Atlas', code: 'C01', tone: '#ff7a3d', lanes: LANE_DEFINITIONS.map(function (lane) { return lane.id; }), summary: 'Complete topology' },
  { id: 'launch', name: 'Launchpad', code: 'C02', tone: '#52d9ff', lanes: ['intake', 'surfaces', 'identity', 'instructions'], summary: 'Task to contract' },
  { id: 'identity', name: 'Identity Mesh', code: 'C03', tone: '#f5d66c', lanes: ['surfaces', 'identity', 'governance'], summary: 'Trust and access' },
  { id: 'capability', name: 'Capability Grid', code: 'C04', tone: '#52d9ff', lanes: ['instructions', 'skills', 'connectors'], summary: 'Skills and tools' },
  { id: 'knowledge', name: 'Knowledge Flow', code: 'C05', tone: '#c5a6ff', lanes: ['knowledge', 'retrieval', 'validation'], summary: 'Evidence path' },
  { id: 'validation', name: 'Validation Gate', code: 'C06', tone: '#f5d66c', lanes: ['retrieval', 'validation', 'governance'], summary: 'Quality and privacy' },
  { id: 'local', name: 'Local Compute', code: 'C07', tone: '#79e7b7', lanes: ['routing', 'local', 'hybrid', 'observe'], summary: 'Private execution' },
  { id: 'hosted', name: 'Hosted Compute', code: 'C08', tone: '#ffaf7d', lanes: ['routing', 'hosted', 'hybrid', 'observe'], summary: 'Elastic reasoning' },
  { id: 'hybrid', name: 'Hybrid Fabric', code: 'C09', tone: '#52d9ff', lanes: ['validation', 'routing', 'local', 'hosted', 'hybrid', 'observe'], summary: 'Thirty six routes' },
  { id: 'observe', name: 'Observability', code: 'C10', tone: '#c5a6ff', lanes: ['routing', 'hybrid', 'observe'], summary: 'Trace and cost' },
  { id: 'governance', name: 'Governance', code: 'C11', tone: '#f5d66c', lanes: ['identity', 'validation', 'observe', 'governance'], summary: 'Policy boundary' },
  { id: 'delivery', name: 'Delivery', code: 'C12', tone: '#ff777d', lanes: ['validation', 'observe', 'governance', 'delivery'], summary: 'Verified release' }
];

function route(id, name, category, color, nodes, rule, latency, cost, privacy) {
  return { id: id, name: name, category: category, color: color, nodes: nodes, rule: rule, latency: latency, cost: cost, privacy: privacy };
}

const ROUTE_DEFINITIONS = [
  route('cost-01', 'Budget scout', 'Cost', '#79e7b7', ['task', 'router', 'tiny', 'quality', 'release'], 'Use tiny local inference for classification and publish only after validation.', 'Fast', 'Lowest', 'Local'),
  route('cost-02', 'Lean drafting', 'Cost', '#79e7b7', ['task', 'skills', 'router', 'small', 'quality', 'release'], 'Keep generation local and reserve hosted capacity for no steps.', 'Fast', 'Low', 'Local'),
  route('cost-03', 'Selective lift', 'Cost', '#79e7b7', ['task', 'router', 'small', 'verifyroute', 'hostfast', 'quality', 'release'], 'Escalate only the uncertain segment after a local first pass.', 'Medium', 'Low', 'Hybrid'),
  route('cost-04', 'Cache and answer', 'Cost', '#79e7b7', ['task', 'chunks', 'vector', 'router', 'small', 'release'], 'Favor cached evidence and a compact local model.', 'Fast', 'Lowest', 'Local'),
  route('cost-05', 'Night shift', 'Cost', '#79e7b7', ['task', 'budget', 'router', 'mid', 'costmeter', 'release'], 'Run a stronger local model under a strict budget governor.', 'Medium', 'Low', 'Local'),
  route('cost-06', 'Value ceiling', 'Cost', '#79e7b7', ['task', 'routepolicy', 'budgetroute', 'hostbalanced', 'costmeter', 'quality', 'release'], 'Allow hosted reasoning until the configured value ceiling is reached.', 'Medium', 'Guarded', 'Hybrid'),
  route('privacy-01', 'Air gap', 'Privacy', '#c5a6ff', ['task', 'workspace', 'policy', 'router', 'small', 'privacy', 'release'], 'Keep inputs, context, inference, and validation on the local machine.', 'Fast', 'Low', 'Maximum'),
  route('privacy-02', 'Local RAG', 'Privacy', '#c5a6ff', ['task', 'catalog', 'chunks', 'vector', 'mid', 'privacy', 'release'], 'Retrieve and generate locally with no hosted context transfer.', 'Medium', 'Low', 'Maximum'),
  route('privacy-03', 'Redacted lift', 'Privacy', '#c5a6ff', ['task', 'policy', 'privacy', 'splitwork', 'hostfast', 'quality', 'release'], 'Redact sensitive context before a narrow hosted call.', 'Medium', 'Guarded', 'High'),
  route('privacy-04', 'Metadata only', 'Privacy', '#c5a6ff', ['task', 'policy', 'localfirst', 'tiny', 'telemetry', 'release'], 'Publish aggregate route metadata while keeping content private.', 'Fast', 'Lowest', 'Maximum'),
  route('privacy-05', 'Verified boundary', 'Privacy', '#c5a6ff', ['task', 'security', 'privacy', 'router', 'mid', 'quality', 'release'], 'Require security and privacy checks before local execution.', 'Medium', 'Low', 'Maximum'),
  route('privacy-06', 'Private fallback', 'Privacy', '#c5a6ff', ['task', 'routepolicy', 'fallback', 'large', 'privacy', 'release'], 'Fall back to the strongest available local model, never to hosted.', 'Slow', 'Local', 'Maximum'),
  route('quality-01', 'Double check', 'Quality', '#ff7a3d', ['task', 'rerank', 'mid', 'quality', 'hostbalanced', 'quality', 'release'], 'Compare a local answer with a hosted review before release.', 'Medium', 'Medium', 'Hybrid'),
  route('quality-02', 'Deep review', 'Quality', '#ff7a3d', ['task', 'skills', 'hostdeep', 'validators', 'quality', 'release'], 'Use deep hosted reasoning and deterministic validators.', 'Slow', 'Higher', 'Hosted'),
  route('quality-03', 'Evidence first', 'Quality', '#ff7a3d', ['task', 'docs', 'chunks', 'rerank', 'hostbalanced', 'quality', 'release'], 'Ground the response in reranked repository evidence.', 'Medium', 'Medium', 'Hybrid'),
  route('quality-04', 'Three pass', 'Quality', '#ff7a3d', ['task', 'small', 'mid', 'hostdeep', 'quality', 'release'], 'Draft, refine, and audit across increasing model capability.', 'Slow', 'Higher', 'Hybrid'),
  route('quality-05', 'Schema locked', 'Quality', '#ff7a3d', ['task', 'prompt', 'schema', 'hostbalanced', 'schema', 'release'], 'Constrain generation with a schema before and after inference.', 'Medium', 'Medium', 'Hosted'),
  route('quality-06', 'Senior gate', 'Quality', '#ff7a3d', ['task', 'mid', 'verifyroute', 'hostdeep', 'validators', 'quality', 'release'], 'Escalate complex findings to deep review and require the full gate.', 'Slow', 'Higher', 'Hybrid'),
  route('latency-01', 'Instant local', 'Latency', '#52d9ff', ['task', 'router', 'tiny', 'release'], 'Take the shortest valid local route for simple transformations.', 'Instant', 'Lowest', 'Local'),
  route('latency-02', 'Fast hosted', 'Latency', '#52d9ff', ['task', 'router', 'hostfast', 'release'], 'Use elastic hosted capacity for rapid burst responses.', 'Instant', 'Low', 'Hosted'),
  route('latency-03', 'Parallel race', 'Latency', '#52d9ff', ['task', 'splitwork', 'small', 'hostfast', 'quality', 'release'], 'Run local and hosted candidates together, then keep the first valid result.', 'Fastest', 'Medium', 'Hybrid'),
  route('latency-04', 'Cached context', 'Latency', '#52d9ff', ['task', 'vector', 'rerank', 'small', 'release'], 'Skip broad discovery by using cached, reranked context.', 'Fast', 'Low', 'Local'),
  route('latency-05', 'Quick verify', 'Latency', '#52d9ff', ['task', 'hostfast', 'validators', 'release'], 'Pair a fast hosted completion with deterministic checks.', 'Fast', 'Low', 'Hosted'),
  route('latency-06', 'Adaptive sprint', 'Latency', '#52d9ff', ['task', 'routepolicy', 'tiny', 'verifyroute', 'hostfast', 'release'], 'Start tiny and lift immediately when confidence drops.', 'Fast', 'Guarded', 'Hybrid'),
  route('offline-01', 'Offline tiny', 'Offline', '#f5d66c', ['task', 'agents', 'skills', 'tiny', 'validators', 'release'], 'Complete small deterministic work with no network dependency.', 'Fast', 'Local', 'Maximum'),
  route('offline-02', 'Offline daily', 'Offline', '#f5d66c', ['task', 'catalog', 'chunks', 'small', 'quality', 'release'], 'Use local repository context and a daily driver model.', 'Medium', 'Local', 'Maximum'),
  route('offline-03', 'Offline code', 'Offline', '#f5d66c', ['task', 'docs', 'mid', 'validators', 'quality', 'release'], 'Run coding work locally with repository checks.', 'Medium', 'Local', 'Maximum'),
  route('offline-04', 'Offline deep', 'Offline', '#f5d66c', ['task', 'rerank', 'large', 'quality', 'release'], 'Use strong local hardware for deeper private reasoning.', 'Slow', 'Local', 'Maximum'),
  route('offline-05', 'Disconnected fallback', 'Offline', '#f5d66c', ['task', 'fallback', 'small', 'validators', 'release'], 'Detect network loss and choose the safe local fallback.', 'Fast', 'Local', 'Maximum'),
  route('offline-06', 'Portable kit', 'Offline', '#f5d66c', ['task', 'setup', 'localfirst', 'tiny', 'privacy', 'release'], 'Use the smallest portable stack for field work.', 'Fast', 'Local', 'Maximum'),
  route('resilience-01', 'Model failover', 'Resilience', '#ff777d', ['task', 'router', 'fallback', 'small', 'hostfast', 'quality', 'release'], 'Move between local and hosted models when one path fails.', 'Variable', 'Guarded', 'Hybrid'),
  route('resilience-02', 'Connector failover', 'Resilience', '#ff777d', ['task', 'apphub', 'fallback', 'catalog', 'router', 'release'], 'Recover from connector loss using repository native context.', 'Variable', 'Low', 'Hybrid'),
  route('resilience-03', 'Validation recovery', 'Resilience', '#ff777d', ['task', 'quality', 'verifyroute', 'hostdeep', 'quality', 'release'], 'Retry failed validation with a stronger reasoning path.', 'Slow', 'Higher', 'Hybrid'),
  route('resilience-04', 'Budget recovery', 'Resilience', '#ff777d', ['task', 'costmeter', 'budgetroute', 'small', 'quality', 'release'], 'Drop to local execution when the hosted budget is exhausted.', 'Medium', 'Low', 'Hybrid'),
  route('resilience-05', 'Privacy recovery', 'Resilience', '#ff777d', ['task', 'privacy', 'fallback', 'mid', 'privacy', 'release'], 'Stay local when a hosted boundary check fails.', 'Medium', 'Local', 'Maximum'),
  route('resilience-06', 'Full circuit', 'Resilience', '#ff777d', ['task', 'routepolicy', 'fallback', 'splitwork', 'hostbalanced', 'telemetry', 'guardian', 'release'], 'Trace every fallback and end at a governed release.', 'Variable', 'Guarded', 'Hybrid')
];

const BACKBONE_EDGES = [
  ['task', 'scope'], ['scope', 'intent'], ['intent', 'codex'], ['intent', 'copilot'], ['intent', 'claude'], ['intent', 'gemini'], ['intent', 'clone'],
  ['codex', 'workspace'], ['copilot', 'workspace'], ['claude', 'profile'], ['gemini', 'profile'], ['clone', 'policy'],
  ['workspace', 'agents'], ['profile', 'prompt'], ['policy', 'budget'], ['agents', 'skills'], ['setup', 'plugins'], ['prompt', 'skills'], ['budget', 'skilltests'],
  ['skills', 'githubmcp'], ['plugins', 'browser'], ['skilltests', 'apphub'], ['githubmcp', 'catalog'], ['context7', 'docs'], ['browser', 'history'],
  ['catalog', 'chunks'], ['docs', 'vector'], ['history', 'rerank'], ['chunks', 'validators'], ['vector', 'schema'], ['rerank', 'quality'],
  ['validators', 'router'], ['schema', 'routepolicy'], ['quality', 'fallback'], ['privacy', 'routepolicy'],
  ['router', 'tiny'], ['router', 'small'], ['routepolicy', 'mid'], ['fallback', 'large'], ['router', 'hostfast'], ['routepolicy', 'hostbalanced'], ['fallback', 'hostdeep'],
  ['tiny', 'localfirst'], ['small', 'splitwork'], ['mid', 'verifyroute'], ['large', 'budgetroute'], ['hostfast', 'splitwork'], ['hostbalanced', 'verifyroute'], ['hostdeep', 'budgetroute'],
  ['localfirst', 'telemetry'], ['splitwork', 'costmeter'], ['verifyroute', 'trace'], ['budgetroute', 'costmeter'],
  ['telemetry', 'guardian'], ['costmeter', 'security'], ['guardian', 'release'], ['security', 'release']
];

const state = {
  canvas: 'atlas',
  platform: localStorage.getItem('atlas-platform') || 'windows',
  zoom: 1,
  selectedNode: null,
  selectedRoute: ROUTE_DEFINITIONS[0],
  routeFilter: 'All',
  search: '',
  drag: null,
  profiles: null
};

function el(tag, className, textValue) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (textValue !== undefined) node.textContent = textValue;
  return node;
}

function svgEl(tag, attrs) {
  const node = document.createElementNS(SVG_NS, tag);
  Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, String(attrs[key])); });
  return node;
}

function getComponent(id) {
  return COMPONENT_DEFINITIONS.find(function (item) { return item.id === id; });
}

function laneIndex(id) {
  return LANE_DEFINITIONS.findIndex(function (lane) { return lane.id === id; });
}

function nodePosition(component) {
  return { x: component.x, y: 43 + laneIndex(component.lane) * 64 };
}

function canvasFor(id) {
  return CANVAS_DEFINITIONS.find(function (item) { return item.id === id; }) || CANVAS_DEFINITIONS[0];
}

function renderCanvasDeck() {
  const deck = document.getElementById('canvasDeck');
  deck.replaceChildren();
  CANVAS_DEFINITIONS.forEach(function (canvas, index) {
    const button = el('button', 'canvas-card' + (canvas.id === state.canvas ? ' active' : ''));
    button.type = 'button';
    button.setAttribute('role', 'listitem');
    button.setAttribute('aria-pressed', String(canvas.id === state.canvas));
    button.dataset.canvas = canvas.id;
    const header = el('header');
    header.append(el('span', '', canvas.code), el('strong', '', canvas.name));
    const mini = el('div', 'mini-map');
    LANE_DEFINITIONS.forEach(function (lane, laneNumber) {
      const mark = el('i');
      mark.style.setProperty('--x', (9 + ((laneNumber * 19 + index * 11) % 68)) + '%');
      mark.style.setProperty('--y', (5 + laneNumber * 5.55) + '%');
      mark.style.setProperty('--w', (canvas.lanes.includes(lane.id) ? 22 : 7) + '%');
      mark.style.setProperty('--tone', canvas.lanes.includes(lane.id) ? canvas.tone : 'rgba(140,148,160,.28)');
      mini.append(mark);
    });
    button.append(header, mini, el('footer', '', canvas.summary));
    button.addEventListener('click', function () { selectCanvas(canvas.id); });
    deck.append(button);
  });
}

function edgeKey(from, to) {
  return from + '>' + to;
}

function routeEdgeSet() {
  const set = new Set();
  if (!state.selectedRoute || state.canvas !== 'hybrid') return set;
  for (let i = 0; i < state.selectedRoute.nodes.length - 1; i += 1) set.add(edgeKey(state.selectedRoute.nodes[i], state.selectedRoute.nodes[i + 1]));
  return set;
}

function drawEdge(layer, fromId, toId, routeSet, focusLanes) {
  const from = getComponent(fromId);
  const to = getComponent(toId);
  if (!from || !to) return;
  const a = nodePosition(from);
  const b = nodePosition(to);
  const x1 = a.x + 146;
  const y1 = a.y + 18;
  const x2 = b.x;
  const y2 = b.y + 18;
  const bend = Math.max(70, Math.abs(x2 - x1) * .42);
  const path = svgEl('path', { d: 'M ' + x1 + ' ' + y1 + ' C ' + (x1 + bend) + ' ' + y1 + ', ' + (x2 - bend) + ' ' + y2 + ', ' + x2 + ' ' + y2, class: 'map-edge' });
  const key = edgeKey(fromId, toId);
  const reverseKey = edgeKey(toId, fromId);
  if (routeSet.has(key) || routeSet.has(reverseKey)) {
    path.classList.add('route-edge');
    path.style.setProperty('--route-color', state.selectedRoute.color);
  } else if (!focusLanes.has(from.lane) && !focusLanes.has(to.lane)) {
    path.classList.add('dim');
  }
  layer.append(path);
}

function renderMap() {
  const diagram = document.getElementById('diagram');
  const title = diagram.querySelector('title');
  const desc = diagram.querySelector('desc');
  diagram.replaceChildren(title, desc);
  const canvas = canvasFor(state.canvas);
  const focusLanes = new Set(canvas.lanes);
  const routeSet = routeEdgeSet();
  const laneLayer = svgEl('g', { class: 'lane-layer' });
  LANE_DEFINITIONS.forEach(function (lane, index) {
    const y = 16 + index * 64;
    laneLayer.append(svgEl('rect', { x: 18, y: y, width: 1884, height: 56, rx: 8, class: 'lane-band' + (index % 2 ? ' alt' : '') }));
    const idx = svgEl('text', { x: 36, y: y + 21, class: 'lane-index' });
    idx.textContent = String(index + 1).padStart(2, '0');
    const label = svgEl('text', { x: 36, y: y + 42, class: 'lane-label' });
    label.textContent = lane.name;
    laneLayer.append(idx, label);
  });
  diagram.append(laneLayer);

  const edgeLayer = svgEl('g', { class: 'edge-layer' });
  const allEdges = new Map();
  BACKBONE_EDGES.forEach(function (pair) { allEdges.set(edgeKey(pair[0], pair[1]), pair); });
  if (state.selectedRoute) {
    for (let i = 0; i < state.selectedRoute.nodes.length - 1; i += 1) {
      const pair = [state.selectedRoute.nodes[i], state.selectedRoute.nodes[i + 1]];
      allEdges.set(edgeKey(pair[0], pair[1]), pair);
    }
  }
  allEdges.forEach(function (pair) { drawEdge(edgeLayer, pair[0], pair[1], routeSet, focusLanes); });
  diagram.append(edgeLayer);

  const nodeLayer = svgEl('g', { class: 'node-layer' });
  COMPONENT_DEFINITIONS.forEach(function (component) {
    const pos = nodePosition(component);
    const group = svgEl('g', {
      class: 'map-node',
      transform: 'translate(' + pos.x + ' ' + pos.y + ')',
      tabindex: '0',
      role: 'button',
      'aria-label': component.name + '. ' + component.detail,
      'data-node': component.id
    });
    group.style.setProperty('--node-color', KIND_COLORS[component.kind]);
    group.append(svgEl('rect', { width: 146, height: 38 }));
    group.append(svgEl('circle', { cx: 13, cy: 13, r: 3, class: 'node-light' }));
    const name = svgEl('text', { x: 23, y: 16, class: 'node-title' });
    name.textContent = component.name;
    const meta = svgEl('text', { x: 13, y: 30, class: 'node-meta' });
    meta.textContent = component.lane.toUpperCase();
    group.append(name, meta);
    if (!focusLanes.has(component.lane)) group.classList.add('dim');
    if (state.selectedNode === component.id) group.classList.add('selected');
    if (state.search && (component.name + ' ' + component.detail + ' ' + component.lane).toLowerCase().includes(state.search)) group.classList.add('search-hit');
    if (state.canvas === 'hybrid' && state.selectedRoute.nodes.includes(component.id)) {
      group.classList.add('route-node');
      group.style.setProperty('--route-color', state.selectedRoute.color);
      group.classList.remove('dim');
    }
    group.addEventListener('click', function () { selectNode(component.id); });
    group.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        selectNode(component.id);
      }
    });
    nodeLayer.append(group);
  });
  diagram.append(nodeLayer);
  diagram.style.width = (1920 * state.zoom) + 'px';
  diagram.style.height = (1080 * state.zoom) + 'px';
  document.getElementById('zoomValue').value = Math.round(state.zoom * 100) + '%';
}

function selectCanvas(id) {
  state.canvas = id;
  const canvas = canvasFor(id);
  document.getElementById('activeCanvasName').textContent = canvas.name;
  document.getElementById('activeCanvasMeta').textContent = canvas.lanes.length + ' focused lanes · 52 components visible';
  renderCanvasDeck();
  renderMap();
}

function connectionCount(id) {
  const keys = new Set();
  BACKBONE_EDGES.forEach(function (pair) { if (pair.includes(id)) keys.add(edgeKey(pair[0], pair[1])); });
  ROUTE_DEFINITIONS.forEach(function (item) {
    item.nodes.forEach(function (nodeId, index) {
      if (nodeId === id && index < item.nodes.length - 1) keys.add(edgeKey(nodeId, item.nodes[index + 1]));
      if (nodeId === id && index > 0) keys.add(edgeKey(item.nodes[index - 1], nodeId));
    });
  });
  return keys.size;
}

function selectNode(id) {
  const component = getComponent(id);
  if (!component) return;
  state.selectedNode = id;
  document.getElementById('setupRail').dataset.component = id;
  document.querySelector('.atlas-frame').classList.add('rail-open');
  document.getElementById('railKind').textContent = component.kind + ' component';
  document.getElementById('railTitle').textContent = component.name;
  document.getElementById('railDescription').textContent = component.detail;
  const stats = document.getElementById('railStats');
  stats.replaceChildren();
  [['Lane', String(laneIndex(component.lane) + 1).padStart(2, '0')], ['Connections', connectionCount(id)]].forEach(function (pair) {
    const card = el('div', 'rail-stat');
    card.append(el('strong', '', pair[1]), el('span', '', pair[0]));
    stats.append(card);
  });
  const command = component.cmd && component.cmd[state.platform];
  const block = document.getElementById('commandBlock');
  block.hidden = !command;
  document.getElementById('railCommand').textContent = command || '';
  renderMap();
}

function renderRouteFilters() {
  const filters = ['All', 'Cost', 'Privacy', 'Quality', 'Latency', 'Offline', 'Resilience'];
  const bar = document.getElementById('routeFilters');
  bar.replaceChildren();
  filters.forEach(function (filter) {
    const button = el('button', filter === state.routeFilter ? 'active' : '', filter);
    button.type = 'button';
    button.setAttribute('aria-pressed', String(filter === state.routeFilter));
    button.addEventListener('click', function () {
      state.routeFilter = filter;
      renderRouteFilters();
      renderRouteCards();
    });
    bar.append(button);
  });
}

function renderRouteCards() {
  const grid = document.getElementById('hybridCards');
  grid.replaceChildren();
  const routes = state.routeFilter === 'All' ? ROUTE_DEFINITIONS : ROUTE_DEFINITIONS.filter(function (item) { return item.category === state.routeFilter; });
  routes.forEach(function (item) {
    const index = ROUTE_DEFINITIONS.indexOf(item) + 1;
    const button = el('button', 'route-card' + (item.id === state.selectedRoute.id ? ' active' : ''));
    button.type = 'button';
    button.style.setProperty('--route-color', item.color);
    const header = el('header');
    header.append(el('span', '', item.category), el('strong', '', String(index).padStart(2, '0')));
    const pathNames = item.nodes.slice(0, 3).map(function (id) { return getComponent(id).name; }).join(' → ');
    const footer = el('footer');
    footer.append(el('i'), el('span', '', pathNames));
    button.append(header, el('h3', '', item.name), el('p', '', item.rule), footer);
    button.addEventListener('click', function () { selectRoute(item); });
    grid.append(button);
  });
}

function selectRoute(item) {
  state.selectedRoute = item;
  renderRouteCards();
  document.getElementById('routeNumber').textContent = String(ROUTE_DEFINITIONS.indexOf(item) + 1).padStart(2, '0');
  document.getElementById('routeTitle').textContent = item.name;
  document.getElementById('routeRule').textContent = item.rule;
  document.getElementById('routeDetail').style.setProperty('--route-color', item.color);
  const path = document.getElementById('routePath');
  path.replaceChildren();
  item.nodes.forEach(function (id, index) {
    if (index) path.append(el('i', '', '→'));
    path.append(el('span', '', getComponent(id).name));
  });
  const metrics = document.getElementById('routeMetrics');
  metrics.replaceChildren();
  [['Latency', item.latency], ['Cost', item.cost], ['Privacy', item.privacy]].forEach(function (pair) {
    const wrap = el('div');
    wrap.append(el('dt', '', pair[0]), el('dd', '', pair[1]));
    metrics.append(wrap);
  });
  if (state.canvas === 'hybrid') renderMap();
}

function setZoom(next) {
  state.zoom = Math.min(1.5, Math.max(.6, next));
  renderMap();
}

function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(function () { toast.classList.remove('show'); }, 1800);
}

async function loadHardware() {
  try {
    const response = await fetch('docs/hardware-profiles.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('profile unavailable');
    state.profiles = await response.json();
    renderHardware();
  } catch (error) {
    document.getElementById('hardwareSummary').textContent = 'The advisor data is unavailable in this preview. The atlas map and routes remain fully interactive.';
  }
}

function renderHardware() {
  if (!state.profiles || !state.profiles.tiers) return;
  const ram = Number(document.getElementById('ramRange').value);
  document.getElementById('ramValue').value = ram + ' GB';
  const eligible = state.profiles.tiers.filter(function (tier) { return Number(tier.ram_gb) <= ram; });
  const tier = eligible[eligible.length - 1] || state.profiles.tiers[0];
  document.getElementById('hardwareStatus').textContent = tier.verdict;
  document.getElementById('hardwareFits').textContent = tier.fits_total;
  document.getElementById('hardwareSummary').textContent = tier.summary;
  const bars = document.getElementById('hardwareBars');
  bars.replaceChildren();
  const values = Object.entries(tier.fits_by_vendor || {});
  const maximum = Math.max.apply(null, values.map(function (pair) { return pair[1]; }).concat([1]));
  values.forEach(function (pair, index) {
    const row = el('div', 'result-bar');
    const bar = el('i');
    bar.style.setProperty('--bar', Math.round(pair[1] / maximum * 100) + '%');
    bar.style.setProperty('--tone', [KIND_COLORS.compute, KIND_COLORS.capability, KIND_COLORS.instruction][index % 3]);
    row.append(el('span', '', pair[0]), bar, el('strong', '', pair[1]));
    bars.append(row);
  });
}

async function loadHealth() {
  try {
    const response = await fetch('docs/catalog-status.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('health unavailable');
    const data = await response.json();
    const counts = data.counts || {};
    document.getElementById('healthyCount').textContent = counts.HEALTHY || 0;
    document.getElementById('staleCount').textContent = counts.STALE || 0;
    document.getElementById('reviewCount').textContent = counts.REVIEW || 0;
    document.getElementById('removeCount').textContent = counts.REMOVE || 0;
    document.getElementById('healthUpdated').textContent = data.updated ? 'Snapshot ' + data.updated : 'Catalog snapshot ready';
    const privateRows = document.getElementById('healthRows');
    if (privateRows && Array.isArray(data.repos)) {
      privateRows.replaceChildren();
      data.repos.slice(0, 12).forEach(function (row) { privateRows.append(el('p', '', String(row.repo || 'Private record') + ' · ' + String(row.status || 'UNKNOWN'))); });
    }
  } catch (error) {
    document.getElementById('healthUpdated').textContent = 'Catalog signal unavailable';
  }
}

async function checkBuild() {
  const localId = document.querySelector('meta[name="build-id"]').content;
  document.getElementById('buildLabel').textContent = localId;
  if (localId === 'dev') return;
  try {
    const response = await fetch('version.json?check=' + Date.now(), { cache: 'no-store' });
    const current = await response.json();
    if (current.build_id && current.build_id !== localId) document.getElementById('staleBar').hidden = false;
  } catch (error) {
    return;
  }
}

function bindControls() {
  document.getElementById('themeToggle').addEventListener('click', function () {
    const html = document.documentElement;
    const next = html.dataset.theme === 'dark' ? 'light' : 'dark';
    html.dataset.theme = next;
    localStorage.setItem('atlas-theme', next);
  });
  const savedTheme = localStorage.getItem('atlas-theme');
  if (savedTheme === 'light' || savedTheme === 'dark') document.documentElement.dataset.theme = savedTheme;

  document.querySelectorAll('#platSeg button').forEach(function (button) {
    const active = button.dataset.platform === state.platform;
    button.setAttribute('aria-pressed', String(active));
    button.addEventListener('click', function () {
      state.platform = button.dataset.platform;
      localStorage.setItem('atlas-platform', state.platform);
      document.querySelectorAll('#platSeg button').forEach(function (item) { item.setAttribute('aria-pressed', String(item === button)); });
      if (state.selectedNode) selectNode(state.selectedNode);
      renderHardware();
    });
  });
  document.getElementById('mapSearch').addEventListener('input', function (event) {
    state.search = event.target.value.trim().toLowerCase();
    renderMap();
  });
  document.addEventListener('keydown', function (event) {
    if (event.key === '/' && !/input|textarea/i.test(document.activeElement.tagName)) {
      event.preventDefault();
      document.getElementById('mapSearch').focus();
    }
    if (event.key === 'Escape') {
      document.querySelector('.atlas-frame').classList.remove('rail-open');
      state.selectedNode = null;
      renderMap();
    }
  });
  document.getElementById('zoomIn').addEventListener('click', function () { setZoom(state.zoom + .1); });
  document.getElementById('zoomOut').addEventListener('click', function () { setZoom(state.zoom - .1); });
  document.getElementById('zoomReset').addEventListener('click', function () { setZoom(1); });
  document.getElementById('railClose').addEventListener('click', function () { document.querySelector('.atlas-frame').classList.remove('rail-open'); state.selectedNode = null; renderMap(); });
  document.getElementById('copyCommand').addEventListener('click', async function () {
    const command = document.getElementById('railCommand').textContent;
    try { await navigator.clipboard.writeText(command); showToast('Command copied'); } catch (error) { showToast('Select and copy the command manually'); }
  });
  document.getElementById('traceRoute').addEventListener('click', function () {
    selectCanvas('hybrid');
    document.getElementById('atlas').scrollIntoView({ behavior: 'smooth', block: 'start' });
    showToast('Tracing ' + state.selectedRoute.name);
  });
  document.getElementById('hardwareRoute').addEventListener('click', function () {
    const ram = Number(document.getElementById('ramRange').value);
    const target = ram >= 24 ? ROUTE_DEFINITIONS.find(function (item) { return item.id === 'offline-04'; }) : ram >= 12 ? ROUTE_DEFINITIONS.find(function (item) { return item.id === 'cost-02'; }) : ROUTE_DEFINITIONS.find(function (item) { return item.id === 'latency-02'; });
    state.routeFilter = 'All';
    selectRoute(target);
    document.getElementById('routes').scrollIntoView({ behavior: 'smooth' });
  });
  document.getElementById('ramRange').addEventListener('input', renderHardware);
  document.getElementById('staleReload').addEventListener('click', function () {
    const target = new URL(window.location.href);
    target.searchParams.set('fresh', Date.now());
    window.location.replace(target.toString());
  });

  const viewport = document.getElementById('mapViewport');
  viewport.addEventListener('pointerdown', function (event) {
    if (event.target.closest('.map-node')) return;
    state.drag = { x: event.clientX, y: event.clientY, left: viewport.scrollLeft, top: viewport.scrollTop };
    viewport.classList.add('dragging');
    viewport.setPointerCapture(event.pointerId);
  });
  viewport.addEventListener('pointermove', function (event) {
    if (!state.drag) return;
    viewport.scrollLeft = state.drag.left - (event.clientX - state.drag.x);
    viewport.scrollTop = state.drag.top - (event.clientY - state.drag.y);
  });
  viewport.addEventListener('pointerup', function () { state.drag = null; viewport.classList.remove('dragging'); });
  viewport.addEventListener('pointercancel', function () { state.drag = null; viewport.classList.remove('dragging'); });
}

function assertRegistry() {
  const errors = [];
  if (LANE_DEFINITIONS.length < 15 || LANE_DEFINITIONS.length > 20) errors.push('lane count must remain between 15 and 20');
  if (CANVAS_DEFINITIONS.length < 10) errors.push('canvas count must remain at least 10');
  if (ROUTE_DEFINITIONS.length <= 30) errors.push('route count must remain above 30');
  if (COMPONENT_DEFINITIONS.length !== ATLAS_META.componentCount) errors.push('component registry does not match metadata');
  if (LANE_DEFINITIONS.length !== ATLAS_META.laneCount || CANVAS_DEFINITIONS.length !== ATLAS_META.canvasCount || ROUTE_DEFINITIONS.length !== ATLAS_META.routeCount) errors.push('atlas registry does not match metadata');
  if (errors.length) throw new Error(errors.join('; '));
}

/* ---------------------------------------------------------------- catalog

   This page carries its own registry: a fifty-two component map of the runtime
   path, asserted by assertRegistry(). That is a deliberate, curated view and is
   not the catalog.

   The catalog is much larger, and until now this page never mentioned it. It
   also never linked to designs/ at all, so twenty-nine working designs were
   being published and were unreachable from the site that publishes them. The
   three renderers below close that: real counts, the Easy Setup profiles, and
   the designs themselves, all read from the generated data rather than typed
   here where they would go stale. */

const catalog = { data: null, os: detectOs(), profile: 'software-developer' };

async function loadCatalog() {
  try {
    const response = await fetch('designs/atlas-data.json', { cache: 'no-store' });
    if (!response.ok) throw new Error('catalog unavailable');
    catalog.data = await response.json();
  } catch (error) {
    /* The map, routes and advisor do not depend on this, so a failure here
       degrades one section rather than the page. Say so where the content
       would have been instead of leaving three empty boxes. */
    const note = document.getElementById('setupNote');
    if (note) note.textContent = 'The catalog data is unavailable in this preview. The map, routes and hardware advisor above remain fully interactive.';
    return;
  }
  renderCatalogMetrics();
  renderSetupControls();
  renderSurfaces();
  renderSetupOutput();
  renderHarness();
  renderStore();
  renderDesignLinks();
}

function renderCatalogMetrics() {
  const meta = catalog.data.meta || {};
  const components = document.getElementById('metricComponents');
  const lanes = document.getElementById('metricLanes');
  if (components && meta.components) components.textContent = meta.components;
  if (lanes && meta.lanes) lanes.textContent = meta.lanes;
  const designs = (catalog.data.designs || []).length;
  const heroDesigns = document.getElementById('heroDesignCount');
  if (heroDesigns) heroDesigns.textContent = designs + ' designs';
  const headCount = document.getElementById('designHeadCount');
  if (headCount) headCount.textContent = designs;
  const heroProfiles = document.getElementById('heroProfileCount');
  const profiles = (catalog.data.profiles || []).length;
  if (heroProfiles) heroProfiles.textContent = profiles + ' profiles';
}

/* --------------------------------------------------------- the surface picker

   This replaced a single-select "which assistant" chip row, which could not say
   the two things that actually matter.

   First, Charles runs several at once, so it is multi-select.

   Second, and this is the honest half: a shell command cannot reach a browser
   product. Emitting a setup line for ChatGPT would look like configuration and
   do nothing at all. So surfaces are grouped by what can genuinely be done to
   them. A CLI on this machine gets a command. A browser surface gets the place
   it actually reads its instructions from. A local model gets offered only if
   the entered memory can hold it.

   The division of labour between the two controls: the ticks decide WHAT gets
   configured, the depth decides HOW MUCH scaffolding goes around it. The depth
   profile supplies the step order, and this code expands its two tokens,
   rules:{client} and the model tokens, from the ticks. */

function detectOs() {
  const ua = (navigator.userAgent || '').toLowerCase();
  if (ua.indexOf('mac') > -1) return 'macos';
  if (ua.indexOf('linux') > -1 && ua.indexOf('android') === -1) return 'linux';
  return 'windows';
}

const picked = new Set(['claude-code']);

function surfacesIn(group) {
  return (catalog.data.surfaces || []).filter(function (s) { return s.group === group; });
}

function ramGb() {
  const field = document.getElementById('setupRam');
  const value = field ? parseInt(field.value, 10) : NaN;
  return Number.isFinite(value) && value > 0 ? value : null;
}

/* A tag whose floor is above the entered memory is not listed at all. Listing it
   greyed out is an invitation to override it, and the override is exactly the
   mistake this control exists to prevent. */
function modelsThatFit() {
  const ram = ramGb();
  if (!ram) return [];
  return surfacesIn('local-model').filter(function (s) { return s.minRamGb <= ram; });
}

function pickedIn(group) {
  return (group === 'local-model' ? modelsThatFit() : surfacesIn(group))
    .filter(function (s) { return picked.has(s.id); });
}

/* The "+" on every group, for a client the vetted list does not name: an open
   frontier model behind an API, Copilot in an editor, a CLI with no hook, a chat
   product. The generator is designs/custom-surfaces.js, shared with every design
   so the two pages cannot drift apart on the commands for the same client, and
   the templates come from atlas-data.json. This file only renders and binds. */
let addingClient = null;
let customDraft = null;
let customResult = null;

function customSurfaces() {
  return typeof window !== 'undefined' ? window.CustomSurfaces : null;
}

function customStepsHtml(result) {
  const cs = customSurfaces();
  return '<ol class="custom-steps">' + result.steps.map(function (step) {
    const words = cs.tokens(step.command).map(function (token) {
      return '<span class="cmd-tok">' + escapeHtml(token) + '</span>';
    }).join(' ');
    return '<li><span class="custom-step-label">' + escapeHtml(step.label) + '</span>' +
      '<div class="harness-check"><code>' + words + '</code>' +
      '<button type="button" class="quiet-button" data-copy-custom="' +
        escapeHtml(step.command) + '" aria-label="Copy: ' + escapeHtml(step.label) +
        '">Copy</button></div></li>';
  }).join('') + '</ol>' +
    '<p class="custom-limit">' + escapeHtml(result.limit || '') + '</p>';
}

function customFormHtml(groupId) {
  const cs = customSurfaces();
  const draft = customDraft || {};
  const kindId = draft.kind || cs.defaultKindFor(catalog.data, groupId);
  const spec = cs.kind(catalog.data, kindId) || {};
  const values = draft.values || {};
  const fields = (spec.fields || []).map(function (field) {
    if (field.options) {
      return '<label class="custom-field"><span>' + escapeHtml(field.label) + '</span>' +
        '<select data-custom-field="' + escapeHtml(field.id) + '">' +
        field.options.map(function (option) {
          const label = (field.optionLabels || {})[option] || option;
          return '<option value="' + escapeHtml(option) + '"' +
            (values[field.id] === option ? ' selected' : '') + '>' + escapeHtml(label) + '</option>';
        }).join('') + '</select></label>';
    }
    return '<label class="custom-field"><span>' + escapeHtml(field.label) + '</span>' +
      '<input type="text" data-custom-field="' + escapeHtml(field.id) + '" value="' +
        escapeHtml(values[field.id] || '') + '" placeholder="' + escapeHtml(field.placeholder || '') +
        '" autocomplete="off" spellcheck="false"></label>';
  }).join('');
  const kindOptions = cs.kinds(catalog.data).map(function (k) {
    return '<option value="' + escapeHtml(k.id) + '"' + (k.id === kindId ? ' selected' : '') +
      '>' + escapeHtml(k.label) + '</option>';
  }).join('');
  let outcome = '';
  if (customResult) {
    outcome = customResult.ok ? customStepsHtml(customResult)
      : '<p class="custom-error" role="alert">' + escapeHtml(customResult.error) + '</p>';
  }
  return '<div class="custom-form" role="group" aria-label="Add a client">' +
    '<label class="custom-field"><span>What kind of client is it?</span>' +
      '<select data-custom-kind>' + kindOptions + '</select></label>' +
    '<p class="custom-plain">' + escapeHtml(spec.plain || '') +
      ' <span>For example: ' + escapeHtml(spec.examples || '') + '</span></p>' +
    '<label class="custom-field"><span>Name it, so you can find it again</span>' +
      '<input type="text" data-custom-name maxlength="60" value="' + escapeHtml(draft.name || '') +
      '" placeholder="' + escapeHtml(cs.namePlaceholder(spec)) + '"></label>' +
    fields +
    '<div class="custom-actions">' +
      '<button type="button" class="quiet-button" data-custom-generate="' + escapeHtml(groupId) +
        '">Show the commands</button>' +
      (customResult && customResult.ok
        ? '<button type="button" class="quiet-button" data-custom-save="' + escapeHtml(groupId) +
          '">Save to this list</button>' : '') +
    '</div>' + outcome + '</div>';
}

function customClientsHtml(groupId) {
  const cs = customSurfaces();
  if (!cs) return '';
  const saved = cs.forGroup(groupId).map(function (item) {
    const result = cs.commands(catalog.data, item.kind, item.values);
    const kindLabel = (cs.kind(catalog.data, item.kind) || {}).label || item.kind;
    return '<details class="custom-client"><summary><b>' + escapeHtml(item.name) + '</b> ' +
      '<span>' + escapeHtml(kindLabel) + '</span></summary>' +
      (result.ok ? customStepsHtml(result)
        : '<p class="custom-error">' + escapeHtml(result.error) + '</p>') +
      '<button type="button" class="quiet-button" data-custom-remove="' + escapeHtml(item.id) +
        '">Remove this client</button></details>';
  }).join('');
  const open = addingClient === groupId;
  return '<div class="custom-clients">' + saved +
    '<button type="button" class="add-client" data-add-client="' + escapeHtml(groupId) +
      '" aria-expanded="' + open + '">' + (open ? 'Close' : '+ Add a client that is not listed') +
    '</button>' + (open ? customFormHtml(groupId) : '') + '</div>';
}

function readCustomDraft(host) {
  const form = host.querySelector('.custom-form');
  const draft = customDraft || {};
  if (!form) return draft;
  const kind = form.querySelector('[data-custom-kind]');
  const name = form.querySelector('[data-custom-name]');
  const values = {};
  form.querySelectorAll('[data-custom-field]').forEach(function (el) {
    values[el.getAttribute('data-custom-field')] = el.value;
  });
  return { kind: kind ? kind.value : draft.kind, name: name ? name.value : draft.name, values: values };
}

function wireCustomClients(host) {
  const cs = customSurfaces();
  if (!cs) return;
  host.querySelectorAll('[data-add-client]').forEach(function (button) {
    button.addEventListener('click', function () {
      const group = button.getAttribute('data-add-client');
      const closing = addingClient === group;
      addingClient = closing ? null : group;
      customDraft = closing ? null : { kind: cs.defaultKindFor(catalog.data, group), values: {} };
      customResult = null;
      renderSurfaces();
    });
  });
  host.querySelectorAll('[data-custom-kind]').forEach(function (select) {
    select.addEventListener('change', function () {
      const draft = readCustomDraft(host);
      customDraft = { kind: select.value, name: draft.name, values: {} };
      customResult = null;
      renderSurfaces();
    });
  });
  host.querySelectorAll('[data-custom-generate]').forEach(function (button) {
    button.addEventListener('click', function () {
      customDraft = readCustomDraft(host);
      customResult = cs.commands(catalog.data, customDraft.kind, customDraft.values);
      renderSurfaces();
    });
  });
  host.querySelectorAll('[data-custom-save]').forEach(function (button) {
    button.addEventListener('click', function () {
      const draft = readCustomDraft(host);
      const saved = cs.save(catalog.data, {
        kind: draft.kind, name: draft.name, values: draft.values,
        group: button.getAttribute('data-custom-save')
      });
      if (saved.ok) {
        addingClient = null; customDraft = null; customResult = null;
        showToast('Saved in this browser');
      } else {
        customResult = { ok: false, error: saved.error };
      }
      renderSurfaces();
    });
  });
  host.querySelectorAll('[data-custom-remove]').forEach(function (button) {
    button.addEventListener('click', function () {
      cs.remove(button.getAttribute('data-custom-remove'));
      renderSurfaces();
    });
  });
  host.querySelectorAll('[data-copy-custom]').forEach(function (button) {
    button.addEventListener('click', function () {
      navigator.clipboard.writeText(button.getAttribute('data-copy-custom')).then(
        function () { showToast('Command copied'); },
        function () { showToast('Select the command and copy it manually'); });
    });
  });
}

function renderSurfaces() {
  const host = document.getElementById('surfaceGroups');
  if (!host || !catalog.data) return;
  const ram = ramGb();
  host.innerHTML = (catalog.data.surfaceGroups || []).map(function (group) {
    const items = group.id === 'local-model' ? modelsThatFit() : surfacesIn(group.id);
    let body;
    if (group.id === 'local-model' && !ram) {
      body = '<p class="group-empty">Enter your system memory above and the tags this machine can hold will appear here.</p>';
    } else if (!items.length) {
      body = '<p class="group-empty">Nothing in the vetted list fits ' + escapeHtml(String(ram)) +
        ' GB. The smallest tag needs 4 GB.</p>';
    } else {
      body = '<div class="surface-grid">' + items.map(function (surface) {
        const on = picked.has(surface.id);
        const floor = surface.minRamGb
          ? '<em class="surface-floor">' + surface.minRamGb + ' GB</em>' : '';
        const enforcement = surface.enforcement || {};
        const enforcementBadge = enforcement.label
          ? '<span class="surface-enforcement" data-kind="' +
              escapeHtml(enforcement.kind || 'rules') + '">' +
              escapeHtml(enforcement.label) + '</span>' : '';
        return '<label class="surface-pick' + (on ? ' on' : '') + '">' +
          '<input type="checkbox" data-surface="' + escapeHtml(surface.id) + '"' +
            (on ? ' checked' : '') + '>' +
          '<span class="surface-body">' +
            '<span class="surface-name">' + escapeHtml(surface.name) + floor + '</span>' +
            '<span class="surface-target">' + escapeHtml(surface.target) + '</span>' +
            enforcementBadge +
            '<span class="surface-detail">' + escapeHtml(surface.detail) + '</span>' +
          '</span></label>';
      }).join('') + '</div>';
    }
    const count = items.filter(function (s) { return picked.has(s.id); }).length;
    return '<section class="surface-group">' +
      '<header class="group-head"><h3>' + escapeHtml(group.name) + '</h3>' +
      '<span class="group-count">' + count + ' of ' + items.length + '</span></header>' +
      '<p class="group-note">' + escapeHtml(group.note) + '</p>' + body +
      customClientsHtml(group.id) + '</section>';
  }).join('');
  wireCustomClients(host);

  host.querySelectorAll('[data-surface]').forEach(function (box) {
    box.addEventListener('change', function () {
      const id = box.getAttribute('data-surface');
      if (box.checked) picked.add(id); else picked.delete(id);
      renderSurfaces();
      renderSetupOutput();
    });
  });
}

function renderSetupControls() {
  const os = document.getElementById('setupOs');
  if (os && !os.dataset.wired) {
    os.innerHTML = [['windows', 'Windows'], ['macos', 'macOS'], ['linux', 'Linux'],
                    ['wsl', 'WSL']].map(function (pair) {
      return '<button type="button" data-setup-os="' + pair[0] + '" aria-pressed="' +
        (pair[0] === catalog.os) + '">' + pair[1] + '</button>';
    }).join('');
    os.dataset.wired = '1';
    os.addEventListener('click', function (event) {
      const button = event.target.closest('[data-setup-os]');
      if (!button) return;
      catalog.os = button.getAttribute('data-setup-os');
      os.querySelectorAll('[data-setup-os]').forEach(function (other) {
        other.setAttribute('aria-pressed', other === button);
      });
      renderSetupOutput();
    });
  }

  const depth = document.getElementById('setupProfile');
  if (depth && !depth.dataset.wired) {
    depth.innerHTML = (catalog.data.profiles || []).map(function (profile) {
      return '<button type="button" data-profile="' + escapeHtml(profile.id) +
        '" aria-pressed="' + (profile.id === catalog.profile) + '">' +
        escapeHtml(profile.name) + '</button>';
    }).join('');
    depth.dataset.wired = '1';
    depth.addEventListener('click', function (event) {
      const button = event.target.closest('[data-profile]');
      if (!button) return;
      catalog.profile = button.getAttribute('data-profile');
      depth.querySelectorAll('[data-profile]').forEach(function (other) {
        other.setAttribute('aria-pressed', other === button);
      });
      renderProfileNote();
      renderSetupOutput();
    });
  }
  renderProfileNote();

  const ram = document.getElementById('setupRam');
  if (ram && !ram.dataset.wired) {
    ram.dataset.wired = '1';
    ram.addEventListener('input', function () {
      /* Lowering the memory can un-fit a tag that is already ticked. Leaving the
         tick would emit a pull for a model this machine cannot hold, so the tick
         goes with the tag rather than surviving out of sight. */
      const floor = ramGb() || 0;
      surfacesIn('local-model').forEach(function (model) {
        if (picked.has(model.id) && model.minRamGb > floor) picked.delete(model.id);
      });
      renderSurfaces();
      renderSetupOutput();
    });
  }
}

function currentProfile() {
  return (catalog.data.profiles || []).filter(function (p) {
    return p.id === catalog.profile;
  })[0] || null;
}

function renderProfileNote() {
  const note = document.getElementById('setupProfileNote');
  const profile = currentProfile();
  if (note && profile) note.textContent = profile.summary;
}

function recipeById(id) {
  return (catalog.data.setupRecipes || []).filter(function (r) { return r.id === id; })[0] || null;
}

function commandFor(id) {
  const recipe = recipeById(id);
  if (!recipe) return null;
  const commands = recipe.commands || {};
  return commands[catalog.os] || commands.other || null;
}

/* Walk the depth profile's own step list and expand its two token kinds from
   the ticks. Keeping the order in the data rather than here means a new profile
   is a data change, and means the order shown on this page is the same order the
   catalog documents everywhere else. */
function stepsForSelection() {
  const profile = currentProfile();
  if (!profile) return { ids: [], dropped: [] };
  const clients = pickedIn('local-client');
  const models = pickedIn('local-model');
  const modelsAllowed = (profile.steps || []).some(function (step) {
    return step.indexOf('model:') === 0 || step === 'ALL_MODEL_TAGS';
  });
  const useModels = modelsAllowed ? models : [];
  if (!clients.length && !useModels.length) return { ids: [], dropped: modelsAllowed ? [] : models };

  const ids = [];
  const seen = {};
  function push(id) {
    if (!id || seen[id]) return;
    seen[id] = true;
    ids.push(id);
  }

  (profile.steps || []).forEach(function (step) {
    // Per-client setup already installs its hooks and skills. Running the
    // all-client installer here would silently undo the checkbox selection.
    if (step === 'setup-rules-guards') return;
    if (step === 'rules:{client}') {
      clients.forEach(function (client) { push(client.setupRecipe); });
      return;
    }
    /* Every model token resolves to the same thing now: the tags that were
       actually ticked. The tier tokens made sense when a single dropdown had to
       guess; a checkbox is a better answer than a guess, and push() keeps the
       tier and tier2 tokens from emitting the same pull twice. */
    if (step.indexOf('model:') === 0 || step === 'ALL_MODEL_TAGS') {
      useModels.forEach(function (model) { push(model.setupRecipe); });
      return;
    }
    if (step === 'setup-ollama-runtime' || step === 'setup-model-list-installed') {
      if (useModels.length) {
        if (step === 'setup-ollama-runtime') push('setup-local-model-harness');
        push(step);
      }
      return;
    }
    push(step);
  });

  return { ids: ids, dropped: modelsAllowed ? [] : models };
}

function renderSetupOutput() {
  const host = document.getElementById('setupOutput');
  if (!host || !catalog.data) return;

  const clients = pickedIn('local-client');
  const models = pickedIn('local-model');
  const web = pickedIn('web-chat').concat(pickedIn('web-code'));
  if (!clients.length && !models.length && !web.length) {
    host.innerHTML = '<p class="setup-empty">Nothing ticked. Choose at least one surface above and the commands appear here.</p>';
    return;
  }

  const plan = stepsForSelection();
  const lines = [];
  plan.ids.forEach(function (id) {
    const command = commandFor(id);
    const recipe = recipeById(id);
    if (!command) return;
    lines.push('# ' + (recipe ? recipe.name : id));
    lines.push(command);
    lines.push('');
  });
  while (lines.length && lines[lines.length - 1] === '') lines.pop();
  const script = lines.join('\n');

  const blocks = [];

  const selected = clients.concat(web, models);
  blocks.push('<article class="out-block enforcement-block"><header class="out-head">' +
    '<h3>What enforces each selection</h3><span class="out-meta">' + selected.length +
    ' selected</span></header><p class="out-lede">A native hook can inject rules into every ' +
    'prompt. Global and repository instructions persist, but the model client controls when ' +
    'they are loaded. Hosted web chats must be configured inside that product.</p>' +
    '<div class="enforcement-grid">' + selected.map(function (surface) {
      const enforcement = surface.enforcement || {};
      const launch = surface.launchCommands
        ? (surface.launchCommands[catalog.os] || surface.launchCommands.other) : '';
      return '<section class="enforcement-row" data-kind="' +
        escapeHtml(enforcement.kind || 'rules') + '"><div><strong>' +
        escapeHtml(surface.name) + '</strong><span>' +
        escapeHtml(enforcement.label || 'Instructions') + '</span></div><p>' +
        escapeHtml(enforcement.detail || surface.detail) + '</p>' +
        (launch ? '<code class="enforcement-command">' + escapeHtml(launch) + '</code>' : '') +
        '</section>';
    }).join('') + '</div></article>');

  if (script) {
    const shellCount = clients.length + models.length;
    let warning = '';
    if (plan.dropped.length) {
      warning = '<p class="out-warn">' + escapeHtml(currentProfile().name) +
        ' installs no models, so ' + plan.dropped.length + ' ticked tag' +
        (plan.dropped.length === 1 ? ' is' : 's are') +
        ' not in this script. Switch the depth to include them.</p>';
    }
    blocks.push('<article class="out-block"><header class="out-head">' +
      '<h3>Run these, in this order</h3><span class="out-meta">' +
      shellCount + ' surface' + (shellCount === 1 ? '' : 's') + ', ' +
      escapeHtml(osLabel(catalog.os)) + '</span></header>' + warning +
      '<pre class="out-code"><code>' + escapeHtml(script) + '</code></pre>' +
      '<button type="button" class="quiet-button" id="copySetup">Copy the script</button>' +
      '</article>');
  }

  if (web.length) {
    const rules = catalog.data.autoMode && catalog.data.autoMode.text
      ? catalog.data.autoMode.text : '';
    blocks.push('<article class="out-block"><header class="out-head">' +
      '<h3>These cannot take a command</h3><span class="out-meta">' +
      web.length + ' browser surface' + (web.length === 1 ? '' : 's') + '</span></header>' +
      '<p class="out-lede">A browser product has no shell on this machine to run against, ' +
      'so it is configured where it actually reads from. Paste the block from ' +
      'docs/auto-mode-block.txt into each target below.</p>' +
      '<dl class="out-steps">' + web.map(function (surface) {
        return '<dt>' + escapeHtml(surface.name) +
          '<span>' + escapeHtml(surface.target) + '</span></dt>' +
          '<dd>' + escapeHtml(surface.detail) + '</dd>';
      }).join('') + '</dl>' + (rules ?
        '<details class="web-rule"><summary>Show the exact protected block</summary>' +
        '<pre class="out-code"><code>' + escapeHtml(rules) + '</code></pre></details>' +
        '<button type="button" class="quiet-button" id="copyWebRules">Copy the protected block</button>'
        : '') + '</article>');
  }

  host.innerHTML = blocks.join('');

  const copy = document.getElementById('copySetup');
  if (copy) {
    copy.addEventListener('click', function () {
      navigator.clipboard.writeText(script).then(function () {
        showToast('Setup script copied');
      }, function () {
        showToast('Select the script and copy it manually');
      });
    });
  }

  const copyRules = document.getElementById('copyWebRules');
  if (copyRules) {
    copyRules.addEventListener('click', function () {
      navigator.clipboard.writeText(catalog.data.autoMode.text).then(function () {
        showToast('Protected auto-mode block copied');
      }, function () {
        showToast('Open the block and copy it manually');
      });
    });
  }
}

function osLabel(id) {
  if (id === 'macos') return 'macOS';
  if (id === 'wsl') return 'WSL';
  return id.charAt(0).toUpperCase() + id.slice(1);
}

/* ------------------------------------------------------------------ the store

   Charles asked to be shown what indexing and the MongoDB store mean here,
   rather than told. So none of this is written prose about a store: every index
   below is parsed out of scripts/monitor-indexes.js by the build, and the page
   renders what that file actually creates. If somebody adds an index and does
   not explain it, the build has no question to show and the test fails. */

/* ------------------------------------------------------------- the harness

   Four cards in a column rather than a four-up grid. They are not
   interchangeable options to scan across; the whole point is what each one can
   and cannot reach, and that is a paragraph of reading each. A grid would say
   "pick one of four similar things", which is the misreading to avoid. */

function renderHarness() {
  const host = document.getElementById('harnessGrid');
  const harnesses = catalog.data.harnesses || [];
  if (!host || !harnesses.length) return;

  host.innerHTML = harnesses.map(function (harness, index) {
    return '<article class="harness-card">' +
      '<header><span class="harness-num">' + String(index + 1).padStart(2, '0') + '</span>' +
      '<div><h3>' + escapeHtml(harness.name) + '</h3>' +
      '<code class="harness-file">' + escapeHtml(harness.file) + '</code></div></header>' +
      '<p class="harness-detail">' + escapeHtml(harness.detail) + '</p>' +
      '<dl class="harness-meta">' +
        '<div><dt>Use it when</dt><dd>' + escapeHtml(harness.useWhen) + '</dd></div>' +
        '<div><dt>What it cannot do</dt><dd>' + escapeHtml(harness.limit) + '</dd></div>' +
      '</dl>' +
      '<div class="harness-check"><code>' + escapeHtml(harness.check) + '</code>' +
      '<button type="button" class="quiet-button" data-copy-harness="' +
        escapeHtml(harness.check) + '">Copy</button></div>' +
      '</article>';
  }).join('');

  host.querySelectorAll('[data-copy-harness]').forEach(function (button) {
    button.addEventListener('click', function () {
      navigator.clipboard.writeText(button.getAttribute('data-copy-harness')).then(
        function () { showToast('Check command copied'); },
        function () { showToast('Select the command and copy it manually'); });
    });
  });

  renderPipeline();

  /* Shown as a real transcript rather than described. The spellings are the part
     people get wrong, so they are on screen rather than in prose. Nothing here
     is required: the first line of the session already set the goal. */
  const example = [
    '# nothing typed. The first real request of a session becomes the goal.',
    'finish the designs and verify each one',
    '',
    '# set one deliberately instead, in any client that has the hook',
    '/goal finish the designs and verify each one',
    '\\goal finish the designs and verify each one',
    '/mastergoal finish the designs and verify each one',
    'goal: finish the designs and verify each one',
    '',
    '# or from the shell, which writes the same store',
    'python scripts/harness_goal.py --set "finish the designs and verify each one"',
    '',
    '# see what is carried, and what a prompt would actually receive',
    'python scripts/harness_goal.py --show',
    'python scripts/harness_goal.py --context "refactor the retry module"',
    '',
    '# end it. Only the person who set it does this.',
    'goal clear',
    'python scripts/harness_goal.py --clear',
  ].join('\n');

  const block = document.getElementById('goalExample');
  if (block) block.textContent = example;

  const copy = document.getElementById('copyGoal');
  if (copy && !copy.dataset.wired) {
    copy.dataset.wired = '1';
    copy.addEventListener('click', function () {
      navigator.clipboard.writeText(example).then(
        function () { showToast('Goal commands copied'); },
        function () { showToast('Select the block and copy it manually'); });
    });
  }
}


/* The standing pipeline, rendered from what the builder read out of
   scripts/hooks/skill_pipeline.py. The page used to describe the layers in
   prose, and the prose said ten rules on an afternoon when the hook injected
   eleven. Reading beats restating. */
function renderPipeline() {
  const pipeline = catalog.data.pipeline;
  if (!pipeline) return;

  const summary = document.getElementById('pipelineSummary');
  if (summary) {
    summary.textContent = pipeline.ruleCount + ' rules in ' +
      (pipeline.layers || []).length + ' base layers for configured hooks and routed ' +
      'requests, with no slash needed on those paths. Web chat uses saved instructions ' +
      'or a paste bundle. ' + pipeline.byteCount + ' base bytes, read from ' + pipeline.source + '.';
  }

  const layers = document.getElementById('pipelineLayers');
  if (layers) {
    layers.innerHTML = (pipeline.layers || []).map(function (layer) {
      return '<section class="pipeline-layer">' +
        '<header><span class="pipeline-layer-num">Layer ' + layer.number + '</span>' +
        '<b>' + escapeHtml(layer.when) + '</b></header>' +
        (layer.simple ? '<p class="pipeline-plain">' + escapeHtml(layer.simple) + '</p>' : '') +
        '<ol class="pipeline-rules">' + (layer.rules || []).map(function (rule) {
          return '<li><span class="pipeline-rule-num">' + rule.number + '</span>' +
            '<b>' + escapeHtml(rule.name) + '</b>' +
            '<span class="pipeline-rule-body">' + escapeHtml(rule.body) + '</span></li>';
        }).join('') + '</ol></section>';
    }).join('');
  }

  const lanes = document.getElementById('pipelineLanes');
  if (lanes) {
    lanes.innerHTML = (pipeline.lanes || []).map(function (lane) {
      return '<li><b>' + escapeHtml(lane.line) + '</b>' +
        '<span>' + escapeHtml(lane.detail) + '</span></li>';
    }).join('');
  }

  const capture = document.getElementById('goalCapture');
  if (capture && pipeline.goal) capture.textContent = pipeline.goal.detail;

  renderSuperChain(pipeline.superChain);
  renderPackage(pipeline.package);
}

/* Install without the repository. The console-script names come from
   pyproject.toml through the payload, so this page cannot offer a command the
   wheel does not ship. */
function renderPackage(pkg) {
  const host = document.getElementById('packageInstall');
  if (!host) return;
  if (!pkg) { host.innerHTML = ''; return; }
  host.innerHTML =
    '<h4>Install it anywhere, without this repository</h4>' +
    '<p class="pipeline-lede">' + escapeHtml(pkg.detail) + '</p>' +
    '<dl class="pack-facts">' +
      '<div><dt>Package</dt><dd><code>' + escapeHtml(pkg.name) + '</code> ' +
        escapeHtml(pkg.version) + '</dd></div>' +
      '<div><dt>Dependencies</dt><dd>' + escapeHtml(pkg.dependencies) + '</dd></div>' +
      '<div><dt>Written up in</dt><dd><code>' + escapeHtml(pkg.doc) + '</code></dd></div>' +
    '</dl>' +
    '<ul class="pack-commands">' + (pkg.commands || []).map(function (name) {
      return '<li><code>' + escapeHtml(name) + '</code></li>';
    }).join('') + '</ul>' +
    (pkg.install || []).map(function (entry) {
      return '<div class="harness-check"><code>' + escapeHtml(entry.command) + '</code>' +
        '<button type="button" class="quiet-button" data-copy-harness="' +
        escapeHtml(entry.command) + '">Copy</button></div>';
    }).join('');

  host.querySelectorAll('[data-copy-harness]').forEach(function (button) {
    button.addEventListener('click', function () {
      navigator.clipboard.writeText(button.getAttribute('data-copy-harness')).then(
        function () { showToast('Command copied'); },
        function () { showToast('Select the command and copy it manually'); });
    });
  });
}

/* The super harness adds passes rather than reach. Rendered from the payload,
   which the builder read out of scripts/harness_super.py, so the page cannot
   list a pass the harness stopped injecting. */
function renderSuperChain(chain) {
  const host = document.getElementById('superChain');
  if (!host) return;
  if (!chain) { host.innerHTML = ''; return; }
  /* The one thing a person types. Spellings come from the payload, which the
     builder parsed with the hook's own parser before shipping. */
  const limit = chain.tokenLimit;
  const limitHtml = limit
    ? '<div class="token-limit"><h5>The one thing you type: /token limit</h5>' +
      '<p>' + escapeHtml(limit.plain) + '</p>' +
      '<ul class="token-spellings" aria-label="Spellings the hook accepts">' +
        (limit.spellings || []).map(function (spelling) {
          return '<li><code>' + escapeHtml(spelling) + '</code></li>';
        }).join('') + '</ul>' +
      '<p class="pipeline-lede">' + escapeHtml(limit.technical) + '</p></div>'
    : '';
  const modeHtml = (chain.modeCommands || []).map(function (entry) {
    return '<p class="custom-step-label">' + escapeHtml(entry.label) + '</p>' +
      '<div class="harness-check"><code>' + escapeHtml(entry.command) + '</code>' +
      '<button type="button" class="quiet-button" data-copy-harness="' +
        escapeHtml(entry.command) + '">Copy</button></div>';
  }).join('');
  host.innerHTML =
    '<h4>' + escapeHtml(chain.name) + ': one command instead of four</h4>' +
    '<p class="pipeline-lede">' + escapeHtml(chain.note) + '</p>' +
    (chain.automatic ? '<p class="pipeline-lede">' + escapeHtml(chain.automatic) + '</p>' : '') +
    '<ol class="chain-steps">' + (chain.passes || []).map(function (step) {
      const body = step.baseRule
        ? 'Rule ' + step.baseRule + ' of the layers above, applied again here.'
        : escapeHtml(step.rule);
      return '<li><span class="chain-step">S' + step.step + '</span><div>' +
        '<b>' + escapeHtml(step.label) + '</b>' +
        '<code class="chain-skill">' + escapeHtml(step.skill) + '</code>' +
        '<span class="chain-when">' + escapeHtml(step.when) + '</span>' +
        '<p>' + body + '</p></div></li>';
    }).join('') + '</ol>' +
    limitHtml +
    '<div class="harness-check"><code>' + escapeHtml(chain.check) + '</code>' +
    '<button type="button" class="quiet-button" data-copy-harness="' +
      escapeHtml(chain.check) + '">Copy</button></div>' +
    (modeHtml ? '<div class="token-modes">' + modeHtml + '</div>' : '');

  host.querySelectorAll('[data-copy-harness]').forEach(function (button) {
    button.addEventListener('click', function () {
      navigator.clipboard.writeText(button.getAttribute('data-copy-harness')).then(
        function () { showToast('Command copied'); },
        function () { showToast('Select the command and copy it manually'); });
    });
  });
}

function renderStore() {
  const store = catalog.data.store;
  if (!store) return;

  const collection = document.getElementById('storeCollection');
  if (collection) collection.textContent = store.document.collection;

  const fields = document.getElementById('storeDocument');
  if (fields) {
    fields.innerHTML = store.document.fields.map(function (field) {
      return '<dt><code>' + escapeHtml(field[0]) + '</code>' +
        '<span class="doc-type">' + escapeHtml(field[1]) + '</span></dt>' +
        '<dd>' + escapeHtml(field[2]) + '</dd>';
    }).join('');
  }

  const count = document.getElementById('storeIndexCount');
  if (count) {
    const collections = store.indexes.map(function (index) { return index.collection; });
    const unique = collections.filter(function (name, at) {
      return collections.indexOf(name) === at;
    });
    count.textContent = store.indexes.length + ' indexes, ' + unique.length + ' collections';
  }

  const list = document.getElementById('storeIndexList');
  if (list) {
    list.innerHTML = store.indexes.map(function (index) {
      /* The badges are the two properties that change what the index DOES rather
         than what it covers, so they are the only two worth calling out. */
      let tags = '';
      if (index.unique) tags += '<span class="index-tag unique">unique</span>';
      if (index.ttl) tags += '<span class="index-tag ttl">TTL</span>';
      return '<li class="index-row">' +
        '<p class="index-question">' + escapeHtml(index.question) + tags + '</p>' +
        '<p class="index-spec"><span class="index-coll">' + escapeHtml(index.collection) +
          '</span><code>' + escapeHtml(index.keys) + '</code>' +
          '<span class="index-name">' + escapeHtml(index.name) + '</span></p>' +
        '<p class="index-why">' + escapeHtml(index.why) + '</p></li>';
    }).join('');
  }

  const search = document.getElementById('storeSearch');
  if (search) {
    search.innerHTML = store.search.map(function (mode) {
      return '<dt>' + escapeHtml(mode.mode) + '</dt><dd>' + escapeHtml(mode.detail) + '</dd>';
    }).join('');
  }

  const command = document.getElementById('storeCommand');
  if (command) command.textContent = store.command;

  const source = document.getElementById('storeSource');
  if (source) {
    source.innerHTML = 'Read from <code>' + escapeHtml(store.file) +
      '</code>. The design behind it is <code>' + escapeHtml(store.doc) + '</code>.';
  }

  const copy = document.getElementById('copyStore');
  if (copy && !copy.dataset.wired) {
    copy.dataset.wired = '1';
    copy.addEventListener('click', function () {
      navigator.clipboard.writeText(store.command).then(function () {
        showToast('Index command copied');
      }, function () {
        showToast('Select the command and copy it manually');
      });
    });
  }
}

/* Each design card says three things now, because one was not enough for the
   range of people who open this page: what it is, who it suits, and the one
   thing to do first. The description is written in interface vocabulary and is
   accurate; "conic specular rim" tells a reader who has not met the words
   nothing at all, and that reader is most of them. */
function renderDesignLinks() {
  const host = document.getElementById('designLinks');
  if (!host) return;
  host.innerHTML = (catalog.data.designs || []).map(function (design) {
    const audience = design.audience
      ? '<span class="design-audience">' + escapeHtml(design.audience) + '</span>' : '';
    const howto = design.howto
      ? '<em class="design-howto">' + escapeHtml(design.howto) + '</em>' : '';
    return '<a class="design-link" href="' + design.file + '">' +
      '<strong>' + escapeHtml(design.name) + audience + '</strong>' +
      '<small>' + escapeHtml(design.detail || '') + '</small>' + howto + '</a>';
  }).join('');
}

function escapeHtml(value) {
  return String(value === null || value === undefined ? '' : value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function init() {
  assertRegistry();
  bindControls();
  renderCanvasDeck();
  renderMap();
  renderRouteFilters();
  selectRoute(state.selectedRoute);
  loadHardware();
  loadHealth();
  loadCatalog();
  checkBuild();
}

document.addEventListener('DOMContentLoaded', init);
