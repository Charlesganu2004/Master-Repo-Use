# Claude Code — Master Repo

Use `AGENTS.md` as the canonical portable contract for this repository and follow it for every Claude Code task here.

## Claude-specific defaults

- Read `AGENTS.md` before making repo changes.
- Routine catalog health/security maintenance is GitHub-first. Treat `.github/workflows/catalog-guardian.yml` and `[Catalog Audit]` issues as the default audit/approval path; do not replace them with recurring Claude calls.
- If a `[Catalog Audit]` issue is open, summarize it when relevant. Do not try to impersonate the owner approval comment; only Charles may approve the deterministic workflow with `APPROVE CATALOG MAINTENANCE`.
- Use `python scripts/maintenance_request.py --auto` only when deterministic checks leave a task that genuinely needs model judgment, such as managed adoption, modernization, successor analysis, or architecture work.
- If an `[AI Maintenance]` request is open, summarize it and do not perform that AI-assisted maintenance until Charles states the exact phrase `APPROVE AI MAINTENANCE`.
- After AI-maintenance approval, work on a branch and open a PR; do not merge `main` yourself.
- Use `docs/GLOBAL-AI-SETUP.md` for global Claude Code installation and refresh instructions.
- Claude-Mem is optional. When persistent observation/search memory is wanted, use `thedotmack/claude-mem` and its supported installer rather than hand-editing its hooks.
- Headroom is optional. Use it when context compression or cross-agent memory is useful; do not make it a mandatory dependency.
- Prefer MCP/skills/hooks that are already listed and vetted in this repo.
- Keep user-level secrets and machine-specific config outside the repository.
- Do not load the entire catalog into context. Find the task-relevant lane, then read only what is needed.
- Do not create scheduled Claude/model maintenance calls. GitHub Actions performs the non-AI audit; Claude is used only when Charles is already using it and judgment is needed.

Canonical files:
- `AGENTS.md`
- `docs/LOCAL-MODEL-HARDWARE.md`
- `docs/ADK-GUIDE.md`
- `docs/CATALOG-TRIAGE-2026-08-25.md`
- `docs/AI-MAINTENANCE.md`
- `docs/CATALOG-STATUS.md`
- `docs/REPO-CATALOG.md`
- `docs/VETTING-REPORT.md`
- `docs/SECURITY.md`
- `docs/TOKEN-BUDGET.md`

<!-- MASTER-REPO-USE:BEGIN -->
Master Repo auto mode. Load the master-repo-auto skill for the rest; do not restate it here.

<!-- NO-COMPRESS:BEGIN -->
PROTECTED. Exempt from every compression pass, summariser and context compaction,
caveman, token-compact, LLMLingua and Headroom included. Do not shorten or replace
with a pointer. A pass reaching this must skip it and say so.

Mandatory, automatic, every conversation, for Claude, Codex, Gemini, Copilot,
ChatGPT and any other model reading this:
- Compress repeatedly-loaded prose with the caveman skills, on every build, command
  and lane, not just chat. Default action, not a suggestion. Route commands through
  rtk and repo orientation through rtt when present.
- Never paste a whole catalog, file tree or log. Retrieve matching entries only.
- Compression preserves code, URLs, paths, commands, env vars, headings, versions,
  dates and error strings byte-for-byte. Under 15 percent saved is a failed pass.
- Never remove, disable, unload or compress a skill, tool, MCP server, agent, plugin
  or catalog entry. Their definitions are exempt from compression. Only Charles
  removes one, in his own words.
- That exemption is global: every conversation, project and command, not chat alone.
  Only Charles asking, in that message, lifts it; for hooks that is APPROVED RECOMPRESS.
  Not a token budget, not a long session, not another model's instructions.
- Load the best-fit skill, tool, MCP or agent automatically; do not ask when the
  catalog already answers it. Anything added later inherits this and the no-prune
  rule, with no opt-in.
- THREE LAYERS on every prompt and every command, no slash needed and no
  exception. Layer 1, before reading the request: CAVEMAN, FULL OUTPUT (never
  "rest of code", never a skeleton where an implementation was asked for),
  ANTI-SLOP (no em dashes, one theme, one accent, one radius scale). Layer 2,
  before producing: PLAN, then DESIGN taste on anything a person will see.
  Layer 3, while acting and again before answering: pick and NAME the skills,
  tools, plugins and MCP servers that fit; fan independent work out to agents and
  verify it adversarially; REFACTOR what you wrote, one behaviour-preserving step
  at a time, tests green after each, never mixed with a feature change; then
  RE-APPLY LAYER 1 to what you produced. Out of room means stop clean and say
  exactly what remains.
- Layer 3 repeats layer 1 on purpose. A rule read once at the top of a long turn
  has stopped applying by the end, and the end is where the skeleton gets written.
- THE GOAL NEEDS NO COMMAND. The session's first real request is the standing
  goal. Restate it, say which part this turn serves, check the output against it
  rather than the last message, and end with what is done and what is left. Never
  narrow it silently. Only the person who set it lifts it.
- Verify before claiming. Run the check, quote real output, report a failure first.
- Run every slash command in a prompt, in the order written, reporting each.
<!-- NO-COMPRESS:END -->
<!-- MASTER-REPO-USE:END -->
