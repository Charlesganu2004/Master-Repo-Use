"""The harness has to work with no repository anywhere.

Every other test in this suite runs inside a checkout, which is exactly the
condition that hides the defects this file exists to catch. A harness that reads
skills/ from the repository root passes all of them and fails the first time
someone pip-installs it, and it fails quietly: `pip install` succeeds, the
commands land on PATH, and each one enforces less than it says it does.

So the slow test is the real one. It builds a wheel, installs it into a
throwaway virtual environment, and runs the commands from a directory with no
checkout in sight. That found, in order:

  - every skill path resolving to site-packages/skills, which does not exist
  - the goal state written into site-packages, which is not writable
  - .github/copilot-instructions.md written into site-packages, where it
    instructs nothing and is deleted on the next upgrade
  - client configs registering hooks that were never bundled
  - an install that registered every hook and copied zero skills
  - the verifier reporting 22 failures against an install that was complete

None of those produced an error. All six were found by running the thing.

The fast tests come first and run always. The build test is marked slow and
skipped without MASTER_HARNESS_BUILD_TEST=1, because building a wheel and
creating a virtualenv takes about a minute and this suite runs constantly.
"""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

import harness_paths  # noqa: E402

BUILD_TEST = os.environ.get("MASTER_HARNESS_BUILD_TEST") == "1"


def sandbox_environment(home: pathlib.Path, scratch: pathlib.Path) -> dict[str, str]:
    """Keep every install, cache and goal write inside this test's scratch root."""
    env = dict(os.environ)
    env.update({
        "HOME": str(home),
        "USERPROFILE": str(home),
        "LOCALAPPDATA": str(home / "local-app-data"),
        "APPDATA": str(home / "app-data"),
        "XDG_DATA_HOME": str(home / "data"),
        "MASTER_REPO_GOAL_DIR": str(scratch / "goal-state"),
        "PIP_CACHE_DIR": str(scratch / "pip-cache"),
        "PIP_CONFIG_FILE": os.devnull,
        "PIP_NO_INDEX": "1",
    })
    env.pop("MASTER_REPO_PATH", None)
    env.pop("PYTHONPATH", None)
    return env


class PackageSandboxEnvironment(unittest.TestCase):
    def test_all_writable_state_is_scoped_to_the_temporary_directory(self):
        with tempfile.TemporaryDirectory(prefix="master-package-env-") as directory:
            scratch = pathlib.Path(directory)
            env = sandbox_environment(scratch / "home", scratch)
            for name in ("HOME", "USERPROFILE", "LOCALAPPDATA", "APPDATA",
                         "XDG_DATA_HOME", "MASTER_REPO_GOAL_DIR", "PIP_CACHE_DIR"):
                self.assertTrue(pathlib.Path(env[name]).is_relative_to(scratch), name)
            self.assertNotIn("MASTER_REPO_PATH", env)
            self.assertNotIn("PYTHONPATH", env)
            self.assertEqual(env["PIP_NO_INDEX"], "1")


class ThePackagingMetadataIsComplete(unittest.TestCase):
    """Cheap checks on the files that decide what the wheel contains."""

    def setUp(self):
        self.pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        self.setup = (ROOT / "setup.py").read_text(encoding="utf-8")

    def test_every_harness_has_a_console_script(self):
        """A harness with no entry point is one an installed user cannot run."""
        for name in ("master-harness", "master-harness-super", "master-harness-proxy",
                     "master-harness-wrap", "master-harness-goal",
                     "master-harness-computer", "master-harness-hook",
                     "master-harness-where", "master-harness-verify"):
            self.assertIn(f"{name} =", self.pyproject, f"{name} has no entry point")

    def test_every_module_the_harness_imports_is_staged(self):
        """A module the build forgets is an ImportError on someone else's
        machine, and never on this one."""
        for module in ("harness_paths.py", "skill_pipeline.py", "auto_mode_harness.py",
                       "harness_proxy.py", "harness_wrap.py", "harness_goal.py",
                       "harness_computer.py", "harness_super.py",
                       "install_auto_mode.py", "verify_auto_mode.py",
                       "no_prune_guard.py", "no_compress_guard.py"):
            self.assertIn(f'"{module}"', self.setup, f"{module} is never staged")

    def test_every_staged_module_exists_in_the_repository(self):
        """The build raises rather than shipping a wheel missing a module, and
        this says so before the build is ever run."""
        import re
        for match in re.finditer(r'ROOT / "scripts"(?: / "hooks")? / "([\w.]+)"', self.setup):
            name = match.group(1)
            candidates = [ROOT / "scripts" / name, ROOT / "scripts" / "hooks" / name]
            self.assertTrue(any(path.is_file() for path in candidates),
                            f"{name} is staged by the build but is not in scripts/")

    def test_the_build_refuses_rather_than_shipping_an_empty_package(self):
        self.assertIn("cannot build:", self.setup)
        self.assertIn("no skills found to bundle", self.setup)

    def test_the_staged_copies_are_not_committed(self):
        """One copy in the repository. A committed second copy is the
        duplication this design exists to avoid, arriving through the back."""
        ignored = (ROOT / ".gitignore").read_text(encoding="utf-8")
        for pattern in ("master_harness/_skills/", "master_harness/_data/",
                        "master_harness/harness_*.py", "master_harness/_agents/"):
            self.assertIn(pattern, ignored, f"{pattern} is not ignored")
        tracked = subprocess.run(["git", "ls-files", "master_harness/"], cwd=ROOT,
                                 capture_output=True, text=True).stdout.split()
        for path in tracked:
            self.assertNotIn("_skills", path, f"a staged copy is committed: {path}")
            self.assertNotIn("_data", path, f"a staged copy is committed: {path}")
            self.assertNotIn("_agents", path, f"a staged copy is committed: {path}")


class TheBuildLeavesNoLitter(unittest.TestCase):
    """A build that drops files in the repository root is a build that will
    eventually have them committed.

    Found by reading git status after a green run, not by anything failing: the
    packaging test overrode HOME, pip resolved its cache relative to the working
    directory, and 1.1 MB of pip/cache/ appeared in the repository root,
    untracked and ungitignored.
    """

    def test_the_packaging_test_pins_the_pip_cache(self):
        source = (ROOT / "tests" / "test_package.py").read_text(encoding="utf-8")
        self.assertIn("PIP_CACHE_DIR", source,
                      "pip will cache relative to cwd once HOME is overridden")

    def test_a_stray_pip_cache_could_not_be_committed(self):
        ignored = (ROOT / ".gitignore").read_text(encoding="utf-8")
        self.assertIn("/pip/", ignored)

    def test_the_repository_root_has_no_pip_cache_right_now(self):
        self.assertFalse((ROOT / "pip").exists(),
                         "a pip cache is sitting in the repository root")

    def test_no_build_output_is_tracked(self):
        tracked = subprocess.run(["git", "ls-files"], cwd=ROOT,
                                 capture_output=True, text=True).stdout.split()
        for path in tracked:
            self.assertFalse(path.startswith("pip/"), f"tracked build litter: {path}")
            self.assertFalse(path.startswith("build/"), f"tracked build litter: {path}")
            self.assertFalse(path.endswith(".whl"), f"tracked wheel: {path}")


class PathsResolveInThisCheckout(unittest.TestCase):
    def test_this_is_recognised_as_a_checkout(self):
        self.assertEqual(harness_paths.repo_root(), ROOT)
        self.assertFalse(harness_paths.installed_standalone())

    def test_the_skills_resolve_to_the_repository(self):
        self.assertEqual(harness_paths.skills_dir(), ROOT / "skills")
        self.assertGreater(len(harness_paths.skill_names()), 15)

    def test_the_state_stays_out_of_the_repository_history(self):
        self.assertEqual(harness_paths.state_dir(), ROOT / ".auto-mode")
        self.assertIn(".auto-mode/", (ROOT / ".gitignore").read_text(encoding="utf-8"))

    def test_an_unset_override_does_not_break_detection(self):
        """MASTER_REPO_PATH pointing at something that is not a checkout must
        report no checkout rather than pretending the directory is one."""
        original = os.environ.get("MASTER_REPO_PATH")
        os.environ["MASTER_REPO_PATH"] = str(ROOT / "docs")
        try:
            self.assertIsNone(harness_paths.repo_root())
        finally:
            if original is None:
                del os.environ["MASTER_REPO_PATH"]
            else:
                os.environ["MASTER_REPO_PATH"] = original

    def test_the_subprocess_command_is_a_file_path_not_a_console_name(self):
        """A console script is what a person types. Spawning one is a different
        problem: on Windows the entry point is master-harness-wrap.exe and the
        bare name raises WinError 2."""
        command = harness_paths.harness_command("harness_wrap")
        self.assertTrue(command[-1].endswith("harness_wrap.py"), command)


@unittest.skipUnless(BUILD_TEST,
                     "set MASTER_HARNESS_BUILD_TEST=1 to build a wheel and install it")
class ItWorksWithNoRepositoryAnywhere(unittest.TestCase):
    """The slow one, and the only one that proves the claim."""

    @classmethod
    def setUpClass(cls):
        cls.scratch = tempfile.mkdtemp(prefix="master-harness-pkg-")
        cls.addClassCleanup(shutil.rmtree, cls.scratch, ignore_errors=True)
        scratch = pathlib.Path(cls.scratch)
        cls.dist = scratch / "dist"
        cls.project = scratch / "project"
        cls.home = scratch / "home"
        cls.project.mkdir()
        cls.home.mkdir()

        # Pin pip's cache into the scratch directory. Without this, a run that
        # overrides HOME leaves pip resolving its cache relative to the working
        # directory, and this test dropped a 1.1 MB pip/cache/ tree into the
        # repository root: untracked, ungitignored, and one careless `git add -A`
        # from being committed. Nothing errored and the test passed.
        cls.build_env = sandbox_environment(cls.home, scratch)

        build = subprocess.run([sys.executable, "-m", "build", "--wheel", "--no-isolation",
                                "--outdir", str(cls.dist)],
                               cwd=ROOT, capture_output=True, text=True, timeout=900,
                               env=cls.build_env)
        if build.returncode != 0:
            raise AssertionError(f"could not build a wheel:\n{build.stdout[-2000:]}\n{build.stderr[-2000:]}")
        wheels = list(cls.dist.glob("*.whl"))
        if not wheels:
            raise AssertionError("the build produced no wheel")

        cls.env = scratch / "env"
        subprocess.run([sys.executable, "-m", "venv", str(cls.env)],
                       capture_output=True, timeout=600, env=cls.build_env, check=True)
        cls.bin = cls.env / ("Scripts" if os.name == "nt" else "bin")
        cls.suffix = ".exe" if os.name == "nt" else ""

        install = subprocess.run([cls.exe("python"), "-m", "pip", "install",
                                  "--quiet", str(wheels[0])],
                                 capture_output=True, text=True, timeout=900,
                                 env=cls.build_env)
        if install.returncode != 0:
            raise AssertionError(f"could not install the wheel:\n{install.stderr[-2000:]}")

        # A directory with no checkout above it, and a home of its own, so
        # nothing this test does can reach the real machine's client configs.

    @classmethod
    def exe(cls, name: str) -> str:
        """Path to a console script in the throwaway environment.

        A classmethod rather than the lambda this started as: assigning a lambda
        to a class attribute makes it a BOUND method, so self.exe("x") passed
        self as the name and every command resolved to a path that does not
        exist. Six tests failed with WinError 2 and none of them was about the
        package.
        """
        return str(cls.bin / f"{name}{cls.suffix}")

    def run_command(self, name, *args, cwd=None):
        env = sandbox_environment(self.home, pathlib.Path(self.scratch))
        return subprocess.run([self.exe(name), *args], cwd=str(cwd or self.project),
                              capture_output=True, text=True, timeout=600, env=env)

    def test_it_knows_it_is_installed_rather_than_in_a_checkout(self):
        result = self.run_command("master-harness-where", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        facts = json.loads(result.stdout)
        self.assertEqual(facts["mode"], "installed")
        self.assertIsNone(facts["repo"])
        self.assertGreater(facts["skillCount"], 15,
                           "the wheel carries no skills; it can enforce nothing")
        self.assertTrue(facts["blockPresent"])

    def test_every_harness_check_passes(self):
        for name in ("master-harness", "master-harness-super", "master-harness-proxy",
                     "master-harness-wrap", "master-harness-goal",
                     "master-harness-computer"):
            result = self.run_command(name, "--check")
            self.assertEqual(result.returncode, 0,
                             f"{name} --check failed:\n{result.stdout}\n{result.stderr}")

    def test_the_hook_injects_the_layers_and_the_refactor_rule(self):
        event = json.dumps({"input": {"prompt": "refactor the retry module"}})
        env = sandbox_environment(self.home, pathlib.Path(self.scratch))
        result = subprocess.run([self.exe("master-harness-hook")], input=event,
                                capture_output=True, text=True, cwd=str(self.project),
                                timeout=120, env=env)
        self.assertEqual(result.returncode, 0, result.stderr)
        context = json.loads(result.stdout)["hookSpecificOutput"]["additionalContext"]
        for marker in ("LAYER 1", "LAYER 2", "LAYER 3", "8. REFACTOR", "11. VERIFY"):
            self.assertIn(marker, context, f"the installed hook is missing {marker}")

    def test_the_goal_survives_between_invocations(self):
        self.run_command("master-harness-goal", "--clear")
        self.run_command("master-harness-goal", "--set", "ship the package")
        shown = self.run_command("master-harness-goal", "--show")
        self.assertIn("ship the package", shown.stdout)

    def test_the_super_chain_reaches_a_wrapped_command(self):
        probe = ("import sys;d=sys.stdin.read();"
                 "print('CHAIN' if 'SUPER HARNESS' in d else 'BASE-ONLY')")
        result = self.run_command("master-harness-super", "--profile", "stdin",
                                  "--run", "--", self.exe("python"), "-c", probe)
        self.assertIn("CHAIN", result.stdout,
                      f"the wrapped command did not get the chain:\n{result.stdout}")

    def test_it_installs_every_client_and_verifies_clean(self):
        """The whole claim, end to end: a machine with no checkout gets the
        skills, the hooks and the instruction files, and the verifier agrees."""
        install = self.run_command("master-harness", "--install", "all")
        self.assertEqual(install.returncode, 0, install.stderr)

        for client in (".claude", ".codex", ".gemini", ".cursor", ".copilot", ".agents"):
            skills = self.home / client / "skills"
            self.assertTrue(skills.is_dir(), f"{client} got no skills directory")
            self.assertGreater(len(list(skills.glob("*/SKILL.md"))), 15,
                               f"{client} got a skills directory with nothing in it")

        verify = self.run_command("master-harness-verify", "--home", str(self.home),
                                  "--repo", str(self.project))
        self.assertIn("0 failed", verify.stdout,
                      f"the install does not verify:\n{verify.stdout}")

    def test_it_never_writes_into_its_own_package_directory(self):
        """site-packages is not a place to keep anything: it is not writable on
        a normal install and it is deleted on the next upgrade. An earlier
        version put .github/copilot-instructions.md there and said nothing."""
        site = self.env / ("Lib" if os.name == "nt" else "lib")
        strays = [path for path in site.rglob(".github")] + \
                 [path for path in site.rglob("*.json") if path.name == "goal.json"]
        self.assertEqual(strays, [], f"the package wrote into itself: {strays}")


class ThePageOffersOnlyCommandsThatExist(unittest.TestCase):
    """A page listing a console script the wheel does not ship is worse than a
    page listing none: the reader tries it."""

    def setUp(self):
        self.data = json.loads(
            (ROOT / "designs" / "atlas-data.json").read_text(encoding="utf-8"))
        self.package = self.data.get("pipeline", {}).get("package")

    def test_the_package_reached_the_payload(self):
        self.assertIsNotNone(self.package, "run scripts/build_atlas_data.py")

    def test_every_console_script_on_the_page_is_declared_by_the_wheel(self):
        pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        for name in self.package["commands"]:
            self.assertIn(f"{name} =", pyproject,
                          f"the page offers {name}, which the wheel does not ship")

    def test_every_console_script_the_wheel_ships_is_on_the_page(self):
        """The other direction. A command nobody is told about is a command
        nobody runs."""
        import re
        pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        block = pyproject.split("[project.scripts]", 1)[1]
        declared = set()
        for line in block.splitlines():
            line = line.strip()
            if line.startswith("["):
                break
            match = re.match(r'([\w-]+)\s*=', line)
            if match:
                declared.add(match.group(1))
        self.assertEqual(declared, set(self.package["commands"]))

    def test_the_version_is_read_rather_than_typed(self):
        pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
        self.assertIn(f'version = "{self.package["version"]}"', pyproject)

    def test_the_install_commands_name_the_real_repository(self):
        joined = " ".join(entry["command"] for entry in self.package["install"])
        self.assertIn("github.com/Charlesganu2004/Master-Repo-Use", joined)
        self.assertIn("master-harness-verify", joined,
                      "an install with no way to check it is an install to distrust")

    def test_the_written_guide_exists(self):
        self.assertTrue((ROOT / self.package["doc"]).is_file())

    def test_both_surfaces_render_it(self):
        panes = (ROOT / "designs" / "atlas-panes.js").read_text(encoding="utf-8")
        core = (ROOT / "designs" / "atlas-core.js").read_text(encoding="utf-8")
        script = (ROOT / "atlas.js").read_text(encoding="utf-8")
        index = (ROOT / "index.html").read_text(encoding="utf-8")
        self.assertIn("function packageHTML(", panes)
        self.assertIn("function packageInfo()", core)
        self.assertIn("function renderPackage(", script)
        self.assertIn('id="packageInstall"', index)

    def test_every_class_it_introduces_is_styled(self):
        styles = (ROOT / "atlas.css").read_text(encoding="utf-8")
        for name in ("pack-facts", "pack-commands"):
            self.assertIn("." + name, styles, f".{name} is rendered with no rule")


if __name__ == "__main__":
    unittest.main()
