"""Paper-first autonomous day-trading agent scaffold."""

__all__ = ["__version__"]
__version__ = "0.1.0"
