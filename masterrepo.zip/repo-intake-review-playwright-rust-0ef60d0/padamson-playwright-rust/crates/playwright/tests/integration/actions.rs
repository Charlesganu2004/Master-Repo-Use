use crate::test_server::TestServer;
use playwright_rs::protocol::action_options::{
    CheckOptions, FillOptions, HoverOptions, KeyboardOptions, MouseOptions, PressOptions,
    SelectOptions,
};
use playwright_rs::protocol::{
    ClickOptions, GotoOptions, MouseButton, Playwright, Position, Scroll,
};

// ============================================================================
// Click Actions
// ============================================================================

#[tokio::test]
async fn test_click_actions() {
    let (_pw, browser, page) = crate::common::setup().await;
    let server = TestServer::start().await;

    // Test 1: Single click button changes its text
    page.goto(&format!("{}/button.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let button = page.locator("#btn");
    button.click(None).await.expect("Failed to click button");

    let text = button.text_content().await.expect("Failed to get text");
    assert_eq!(text, Some("clicked".to_string()));

    // Test 2: Double-click changes div text
    page.goto(&format!("{}/dblclick.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let div = page.locator("#target");
    div.dblclick(None).await.expect("Failed to double-click");

    let text = div.text_content().await.expect("Failed to get text");
    assert_eq!(text, Some("double clicked".to_string()));

    browser.close().await.expect("Failed to close browser");
    server.shutdown();
}

// ============================================================================
// Fill and Clear Actions
// ============================================================================

#[tokio::test]
async fn test_fill_and_clear_actions() {
    let (_pw, browser, page) = crate::common::setup().await;
    let server = TestServer::start().await;

    page.goto(&format!("{}/form.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    // Test 1: Fill input field
    let input = page.locator("#name");
    input
        .fill("John Doe", None)
        .await
        .expect("Failed to fill input");

    let value = input
        .input_value(None)
        .await
        .expect("Failed to get input value");
    assert_eq!(value, "John Doe");

    // Test 2: Fill textarea
    let textarea = page.locator("#bio");
    textarea
        .fill("Hello\nWorld", None)
        .await
        .expect("Failed to fill textarea");

    let value = textarea
        .input_value(None)
        .await
        .expect("Failed to get textarea value");
    assert_eq!(value, "Hello\nWorld");

    // Test 3: Clear input field with initial value
    page.goto(&format!("{}/input.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let clear_input = page.locator("#input");

    // Verify initial value
    let initial_value = clear_input
        .input_value(None)
        .await
        .expect("Failed to get initial value");
    assert_eq!(initial_value, "initial");

    // Clear the input
    clear_input
        .clear(None)
        .await
        .expect("Failed to clear input");

    // Verify input is now empty
    let cleared_value = clear_input
        .input_value(None)
        .await
        .expect("Failed to get cleared value");
    assert_eq!(cleared_value, "");

    browser.close().await.expect("Failed to close browser");
    server.shutdown();
}

// ============================================================================
// Keyboard Actions
// ============================================================================

#[tokio::test]
async fn test_keyboard_actions() {
    let (_pw, browser, page) = crate::common::setup().await;
    let server = TestServer::start().await;

    page.goto(&format!("{}/keyboard.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    // Test: Press Enter key changes input value via JavaScript
    let input = page.locator("#input");
    input.click(None).await.expect("Failed to focus input");
    input
        .press("Enter", None)
        .await
        .expect("Failed to press Enter");

    // Verify keypress had effect (keyboard.html sets value to "submitted" on Enter)
    let value = input
        .input_value(None)
        .await
        .expect("Failed to get input value");
    assert_eq!(value, "submitted");

    browser.close().await.expect("Failed to close browser");
    server.shutdown();
}

// ============================================================================
// Cross-browser Smoke Test
// ============================================================================

#[tokio::test]
#[ignore]
async fn test_cross_browser_smoke() {
    crate::common::init_tracing();
    // Smoke test to verify actions work in Firefox and WebKit
    // (Rust bindings use the same protocol layer for all browsers,
    //  so we don't need exhaustive cross-browser testing for each action)

    let server = TestServer::start().await;
    let playwright = Playwright::launch()
        .await
        .expect("Failed to launch Playwright");

    // Test Firefox
    let firefox = playwright
        .firefox()
        .launch()
        .await
        .expect("Failed to launch Firefox");
    let firefox_page = firefox.new_page().await.expect("Failed to create page");

    firefox_page
        .goto(
            &format!("{}/button.html", server.url()),
            Some(GotoOptions::new().timeout(std::time::Duration::from_secs(60))),
        )
        .await
        .expect("Failed to navigate");

    let firefox_button = firefox_page.locator("#btn");
    firefox_button
        .click(None)
        .await
        .expect("Failed to click button");

    let text = firefox_button
        .text_content()
        .await
        .expect("Failed to get text");
    assert_eq!(text, Some("clicked".to_string()));

    firefox.close().await.expect("Failed to close Firefox");

    // Test WebKit
    let webkit = playwright
        .webkit()
        .launch()
        .await
        .expect("Failed to launch WebKit");
    let webkit_page = webkit.new_page().await.expect("Failed to create page");

    webkit_page
        .goto(
            &format!("{}/form.html", server.url()),
            Some(GotoOptions::new().timeout(std::time::Duration::from_secs(60))),
        )
        .await
        .expect("Failed to navigate");

    let webkit_input = webkit_page.locator("#name");
    webkit_input
        .fill("Test", None)
        .await
        .expect("Failed to fill input");

    // Verify the input value
    let value = webkit_input
        .input_value(None)
        .await
        .expect("Failed to get input value");
    assert_eq!(value, "Test");

    webkit.close().await.expect("Failed to close WebKit");
    server.shutdown();
}

// ============================================================================
// Action Options Methods
// ============================================================================

#[tokio::test]
async fn test_action_options_methods() {
    let (_pw, browser, page) = crate::common::setup().await;
    let server = TestServer::start().await;

    // Test 1: Fill with force option
    page.goto(&format!("{}/input.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let input = page.locator("#input");
    let options = FillOptions::builder().force(true).build();
    input
        .fill("Hello World", Some(options))
        .await
        .expect("Failed to fill with force");

    let value = input.input_value(None).await.unwrap();
    assert_eq!(value, "Hello World");

    tracing::info!("✓ Fill with force option works");

    // Test 2: Press with delay option
    page.goto(&format!("{}/keyboard.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let input = page.locator("#input");
    input.click(None).await.expect("Failed to click");

    let options = PressOptions::builder().delay(50.0).build();
    input
        .press("Enter", Some(options))
        .await
        .expect("Failed to press with delay");

    let value = input.input_value(None).await.unwrap();
    assert_eq!(value, "submitted");

    tracing::info!("✓ Press with delay option works");

    // Test 3: Check with force and trial options
    page.goto(&format!("{}/checkbox.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let checkbox = page.locator("#checkbox");
    let options = CheckOptions::builder().force(true).build();
    checkbox
        .check(Some(options))
        .await
        .expect("Failed to check with force");

    assert!(
        checkbox.is_checked().await.unwrap(),
        "Checkbox should be checked"
    );

    let checked_checkbox = page.locator("#checked-checkbox");
    let trial_options = CheckOptions::builder().trial(true).build();
    checked_checkbox
        .uncheck(Some(trial_options))
        .await
        .expect("Failed to trial uncheck");

    assert!(
        checked_checkbox.is_checked().await.unwrap(),
        "Trial uncheck should not actually uncheck"
    );

    tracing::info!("✓ Check with force and trial options work");

    // Test 4: Hover with position option
    page.goto(&format!("{}/hover.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let button = page.locator("#hover-button");
    let options = HoverOptions::builder()
        .position(Position { x: 5.0, y: 5.0 })
        .build();
    button
        .hover(Some(options))
        .await
        .expect("Failed to hover with position");

    let tooltip = page.locator("#tooltip");
    assert!(
        tooltip.is_visible().await.unwrap(),
        "Tooltip should be visible after hover"
    );

    tracing::info!("✓ Hover with position option works");

    // Test 5: Select with force option
    page.goto(&format!("{}/select.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let select = page.locator("#single-select");
    let options = SelectOptions::builder().force(true).build();
    let selected = select
        .select_option("apple", Some(options))
        .await
        .expect("Failed to select with force");

    assert_eq!(selected, vec!["apple"]);

    tracing::info!("✓ Select with force option works");

    // Test 6: Keyboard type with delay option
    page.goto(&format!("{}/keyboard_mouse.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    let input = page.locator("#keyboard-input");
    input.click(None).await.expect("Failed to click input");

    let keyboard = page.keyboard();
    let options = KeyboardOptions::builder().delay(10.0).build();
    keyboard
        .type_text("Hello", Some(options))
        .await
        .expect("Failed to type with delay");

    let value = input.input_value(None).await.unwrap();
    assert_eq!(value, "Hello");

    tracing::info!("✓ Keyboard type with delay option works");

    // Test 7: Mouse click with options
    let mouse = page.mouse();
    let options = MouseOptions::builder()
        .button(MouseButton::Left)
        .click_count(1)
        .build();
    mouse
        .click(150.0, 150.0, Some(options))
        .await
        .expect("Failed to click with options");

    let result = page.locator("#mouse-result").inner_text().await.unwrap();
    assert_eq!(result, "Clicked");

    tracing::info!("✓ Mouse click with options works");

    browser.close().await.expect("Failed to close browser");
    server.shutdown();
}

// ============================================================================
// Cross-browser Smoke Test
// ============================================================================

#[tokio::test]
#[ignore]
async fn test_action_options_cross_browser_smoke() {
    crate::common::init_tracing();
    // Smoke test to verify action options work in Firefox and WebKit
    // (Rust bindings use the same protocol layer for all browsers,
    //  so we don't need exhaustive cross-browser testing for each method)

    let server = TestServer::start().await;
    let playwright = Playwright::launch()
        .await
        .expect("Failed to launch Playwright");

    // Test Firefox - fill with options
    let firefox = playwright
        .firefox()
        .launch()
        .await
        .expect("Failed to launch Firefox");
    let firefox_page = firefox.new_page().await.expect("Failed to create page");

    firefox_page
        .goto(
            &format!("{}/input.html", server.url()),
            Some(GotoOptions::new().timeout(std::time::Duration::from_secs(60))),
        )
        .await
        .expect("Failed to navigate");

    let firefox_input = firefox_page.locator("#input");
    let options = FillOptions::builder().force(true).build();
    firefox_input
        .fill("Firefox Test", Some(options))
        .await
        .expect("Failed to fill in Firefox");

    let value = firefox_input.input_value(None).await.unwrap();
    assert_eq!(value, "Firefox Test");

    tracing::info!("✓ Firefox action options work");

    firefox.close().await.expect("Failed to close Firefox");

    // Test WebKit - check with options
    let webkit = playwright
        .webkit()
        .launch()
        .await
        .expect("Failed to launch WebKit");
    let webkit_page = webkit.new_page().await.expect("Failed to create page");

    webkit_page
        .goto(
            &format!("{}/checkbox.html", server.url()),
            Some(GotoOptions::new().timeout(std::time::Duration::from_secs(60))),
        )
        .await
        .expect("Failed to navigate");

    let webkit_checkbox = webkit_page.locator("#checkbox");
    let options = CheckOptions::builder().force(true).build();
    webkit_checkbox
        .check(Some(options))
        .await
        .expect("Failed to check in WebKit");

    assert!(
        webkit_checkbox.is_checked().await.unwrap(),
        "Checkbox should be checked in WebKit"
    );

    tracing::info!("✓ WebKit action options work");

    webkit.close().await.expect("Failed to close WebKit");
    server.shutdown();
}

#[tokio::test]
async fn test_scroll_none_refuses_to_scroll_into_view() {
    let (_pw, _browser, page) = crate::common::setup().await;

    // A button pushed far below the fold, so acting on it requires scrolling.
    page.set_content(
        "<div style='height:5000px'></div>\
         <button id='below'>below the fold</button>",
        None,
    )
    .await
    .expect("set_content");

    let button = page.locator("#below");

    // Scroll::None opts out of the scroll-into-view that actionability
    // normally performs, so the click can never become actionable and times
    // out instead. Short timeout: we are asserting the refusal, not waiting.
    let refused = button
        .click(
            ClickOptions::builder()
                .scroll(Scroll::None)
                .timeout(1500.0)
                .build(),
        )
        .await;
    assert!(
        refused.is_err(),
        "Scroll::None should refuse to scroll an out-of-view element into view"
    );

    // The default scrolls, so the same click succeeds. This is the half that
    // proves the failure above came from the option and not from the fixture.
    button
        .click(ClickOptions::builder().timeout(5000.0).build())
        .await
        .expect("default scroll behaviour should bring the button into view");
}
