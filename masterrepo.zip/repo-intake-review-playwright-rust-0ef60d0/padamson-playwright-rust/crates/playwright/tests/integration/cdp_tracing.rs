// CDPSession and Tracing — Chromium-only (CDP is not available in Firefox/WebKit).

// ============================================================================
// CDPSession Tests
// ============================================================================

#[tokio::test]
async fn test_new_cdp_session_basic() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let page = context.new_page().await.expect("Failed to create page");

    // Create a CDP session for the page
    let session = context
        .new_cdp_session(&page)
        .await
        .expect("Failed to create CDP session");

    // Send a simple CDP command: Runtime.evaluate with expression "1+1"
    let result = session
        .send(
            "Runtime.evaluate",
            Some(serde_json::json!({ "expression": "1+1" })),
        )
        .await
        .expect("Failed to send CDP command");

    // The CDP response is double-nested:
    // result = { "result": { "result": { "description": "2", "type": "number", "value": 2 } } }
    // Outer "result" is the protocol envelope field; inner "result" is the CDP returnValue.
    let value = result
        .get("result")
        .and_then(|r| r.get("result"))
        .and_then(|r| r.get("value"))
        .and_then(|v| v.as_f64())
        .expect("Expected numeric result from Runtime.evaluate");
    assert_eq!(value as i64, 2, "1+1 should equal 2");

    // Detach the session
    session
        .detach()
        .await
        .expect("Failed to detach CDP session");

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_new_cdp_session_send_no_params() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let page = context.new_page().await.expect("Failed to create page");

    let session = context
        .new_cdp_session(&page)
        .await
        .expect("Failed to create CDP session");

    // Send a CDP command with no params — Runtime.getIsolateId
    let result = session
        .send("Runtime.getIsolateId", None)
        .await
        .expect("Failed to send CDP command without params");

    // The response is double-nested: { "result": { "id": "..." } }
    // The outer "result" is the Playwright protocol envelope; inner is the CDP response.
    let inner = result
        .get("result")
        .expect("Expected result in CDP response");
    assert!(
        inner.get("id").is_some(),
        "Runtime.getIsolateId should return an id, got: {:?}",
        inner
    );

    session
        .detach()
        .await
        .expect("Failed to detach CDP session");

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_new_cdp_session_navigate_and_evaluate() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let page = context.new_page().await.expect("Failed to create page");

    // Navigate to a page first
    page.goto(
        "data:text/html,<html><body><h1 id='title'>Hello CDP</h1></body></html>",
        None,
    )
    .await
    .expect("Failed to navigate");

    let session = context
        .new_cdp_session(&page)
        .await
        .expect("Failed to create CDP session");

    // Use CDP to evaluate document.title
    let result = session
        .send(
            "Runtime.evaluate",
            Some(serde_json::json!({
                "expression": "document.getElementById('title').textContent"
            })),
        )
        .await
        .expect("Failed to send CDP command");

    let value = result
        .get("result")
        .and_then(|r| r.get("result"))
        .and_then(|r| r.get("value"))
        .and_then(|v| v.as_str())
        .expect("Expected string result");
    assert_eq!(value, "Hello CDP");

    session
        .detach()
        .await
        .expect("Failed to detach CDP session");

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_cdp_session_on_fires_for_network_event() {
    use std::sync::Arc;
    use std::sync::atomic::{AtomicBool, Ordering};
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;
    let page = context.new_page().await.expect("Failed to create page");
    let session = context
        .new_cdp_session(&page)
        .await
        .expect("Failed to create CDP session");

    let saw_request = Arc::new(AtomicBool::new(false));
    let flag = saw_request.clone();
    session.on("Network.requestWillBeSent", move |_params| {
        let flag = flag.clone();
        async move {
            flag.store(true, Ordering::SeqCst);
            Ok(())
        }
    });

    session
        .send("Network.enable", None)
        .await
        .expect("Failed to enable Network domain");

    page.goto(
        "data:text/html,<html><body>cdp event test</body></html>",
        None,
    )
    .await
    .expect("Failed to navigate");

    // Trigger a real network request (data: URLs don't always emit
    // requestWillBeSent on every chromium build, so we issue a fetch
    // to a same-origin no-op URL).
    let _ = page
        .evaluate_value("fetch('data:text/plain,x').catch(()=>{})")
        .await;

    let mut waited = std::time::Duration::ZERO;
    while !saw_request.load(Ordering::SeqCst) && waited < std::time::Duration::from_secs(5) {
        tokio::time::sleep(std::time::Duration::from_millis(50)).await;
        waited += std::time::Duration::from_millis(50);
    }
    assert!(
        saw_request.load(Ordering::SeqCst),
        "Network.requestWillBeSent handler should have fired within 5s"
    );

    session
        .detach()
        .await
        .expect("Failed to detach CDP session");
    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_cdp_session_on_close_fires_on_detach() {
    use std::sync::Arc;
    use std::sync::atomic::{AtomicBool, Ordering};
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;
    let page = context.new_page().await.expect("Failed to create page");
    let session = context
        .new_cdp_session(&page)
        .await
        .expect("Failed to create CDP session");

    let closed = Arc::new(AtomicBool::new(false));
    let flag = closed.clone();
    session.on_close(move || {
        let flag = flag.clone();
        async move {
            flag.store(true, Ordering::SeqCst);
            Ok(())
        }
    });

    session
        .detach()
        .await
        .expect("Failed to detach CDP session");

    let mut waited = std::time::Duration::ZERO;
    while !closed.load(Ordering::SeqCst) && waited < std::time::Duration::from_secs(2) {
        tokio::time::sleep(std::time::Duration::from_millis(20)).await;
        waited += std::time::Duration::from_millis(20);
    }
    assert!(
        closed.load(Ordering::SeqCst),
        "close handler should have fired after detach"
    );

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

// ============================================================================
// Tracing Tests
// ============================================================================

#[tokio::test]
async fn test_tracing_start_stop() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    // Get the tracing object from the context
    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    // Start tracing with no options
    tracing.start(None).await.expect("Failed to start tracing");

    // Do some activity to trace
    let page = context.new_page().await.expect("Failed to create page");
    page.goto(
        "data:text/html,<html><body>Tracing test</body></html>",
        None,
    )
    .await
    .expect("Failed to navigate");

    // Stop tracing — just verify it succeeds without saving to a file
    tracing.stop(None).await.expect("Failed to stop tracing");

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_tracing_start_with_options() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    // Start tracing with name and screenshot options
    use playwright_rs::protocol::TracingStartOptions;
    let options = TracingStartOptions::default()
        .name("test-trace")
        .screenshots(true)
        .snapshots(true);

    tracing
        .start(Some(options))
        .await
        .expect("Failed to start tracing with options");

    // A page that keeps repainting: screencast frames follow paints, and a
    // static page paints once, which under load can land after the stop.
    let page = context.new_page().await.expect("Failed to create page");
    page.goto(
        "data:text/html,<html><body><script>window.ticks = 0; setInterval(() => { window.ticks += 1; document.body.textContent = 'tick ' + window.ticks; }, 50);</script></body></html>",
        None,
    )
    .await
    .expect("Failed to navigate");
    page.wait_for_function("() => window.ticks > 5", None)
        .await
        .expect("the page keeps painting");

    // Read the trace back: the driver ignores capture keys it does not
    // know, so only the recorded content proves the options took effect.
    use playwright_rs::protocol::TracingStopOptions;
    use playwright_rs_trace::TraceEvent;
    let dir = tempfile::tempdir().expect("tempdir");
    let path = dir.path().join("trace.zip");
    tracing
        .stop(Some(
            TracingStopOptions::default().path(path.to_str().expect("utf-8 path")),
        ))
        .await
        .expect("Failed to stop tracing with options");

    let mut reader = playwright_rs_trace::open(&path).expect("open the recorded trace");
    let events: Vec<_> = reader
        .events()
        .expect("events")
        .collect::<Result<_, _>>()
        .expect("typed events");
    assert!(
        events
            .iter()
            .any(|e| matches!(e, TraceEvent::FrameSnapshot(_))),
        "snapshots(true) must record DOM snapshots"
    );
    assert!(
        events
            .iter()
            .any(|e| matches!(e, TraceEvent::ScreencastFrame(_))),
        "screenshots(true) must record screencast frames"
    );

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_tracing_stop_with_path() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    // Start tracing with snapshots so there's data to save
    use playwright_rs::protocol::TracingStartOptions;
    let start_options = TracingStartOptions::default()
        .name("path-test-trace")
        .screenshots(false)
        .snapshots(true);

    tracing
        .start(Some(start_options))
        .await
        .expect("Failed to start tracing");

    let page = context.new_page().await.expect("Failed to create page");
    page.goto(
        "data:text/html,<html><body>Trace to file</body></html>",
        None,
    )
    .await
    .expect("Failed to navigate");

    // Stop tracing and save to a temp file
    let temp_path = std::env::temp_dir().join(format!(
        "pw-rust-trace-test-{}.zip",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));

    use playwright_rs::protocol::TracingStopOptions;
    let stop_options = TracingStopOptions::default().path(temp_path.to_str().unwrap());

    tracing
        .stop(Some(stop_options))
        .await
        .expect("Failed to stop tracing with path");

    // The trace file should exist if the path was provided
    // Note: actual file creation depends on Playwright artifact handling
    // For now just verify the stop succeeded

    // Cleanup
    let _ = std::fs::remove_file(&temp_path);

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_tracing_start_with_live_option() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    // The Playwright server's tracingStart accepts `live: true` to allow a
    // viewer to attach to an in-progress trace. We can't drive an actual
    // viewer from a unit test, so this test verifies that:
    //   1. The option is accepted (no protocol error)
    //   2. A recording with `live: true` still produces a valid trace file
    use playwright_rs::protocol::{TracingStartOptions, TracingStopOptions};
    let start_options = TracingStartOptions::default()
        .name("live-trace")
        .screenshots(true)
        .snapshots(true)
        .live(true);

    tracing
        .start(Some(start_options))
        .await
        .expect("Failed to start tracing with live: true");

    // Generate some activity so the trace has content
    let page = context.new_page().await.expect("Failed to create page");
    page.goto("data:text/html,<html><body>Live trace</body></html>", None)
        .await
        .expect("Failed to navigate");

    // Stop and save the trace file; verify it's a valid (non-empty) zip
    let temp_path = std::env::temp_dir().join(format!(
        "pw-rust-live-trace-{}.zip",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));

    let stop_options = TracingStopOptions::default().path(temp_path.to_str().unwrap());

    tracing
        .stop(Some(stop_options))
        .await
        .expect("Failed to stop tracing with live: true");

    // The trace file should be a non-empty zip archive
    if let Ok(metadata) = std::fs::metadata(&temp_path) {
        assert!(
            metadata.len() > 0,
            "Live trace file should be non-empty: {}",
            temp_path.display()
        );
    }

    // Cleanup
    let _ = std::fs::remove_file(&temp_path);

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_tracing_multiple_start_stop_cycles() {
    crate::common::init_tracing();

    let (playwright, browser, context) = crate::common::setup_context().await;

    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    // First cycle
    tracing
        .start(None)
        .await
        .expect("Failed to start tracing (cycle 1)");

    let page = context.new_page().await.expect("Failed to create page");
    page.goto("data:text/html,<html><body>Cycle 1</body></html>", None)
        .await
        .expect("Failed to navigate (cycle 1)");

    tracing
        .stop(None)
        .await
        .expect("Failed to stop tracing (cycle 1)");

    // Second cycle — should work again
    tracing
        .start(None)
        .await
        .expect("Failed to start tracing (cycle 2)");

    page.goto("data:text/html,<html><body>Cycle 2</body></html>", None)
        .await
        .expect("Failed to navigate (cycle 2)");

    tracing
        .stop(None)
        .await
        .expect("Failed to stop tracing (cycle 2)");

    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    drop(playwright);
}

#[tokio::test]
async fn test_tracing_har_records_network() {
    use playwright_rs::protocol::StartHarOptions;

    let server = crate::test_server::TestServer::start().await;
    let (playwright, browser, context) = crate::common::setup_context().await;
    let tracing = context
        .tracing()
        .await
        .expect("Failed to get tracing object");

    let har_path = std::env::temp_dir().join(format!(
        "pw-rust-har-{}.har",
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));

    tracing
        .start_har(har_path.to_str().unwrap(), Some(StartHarOptions::default()))
        .await
        .expect("Failed to start HAR recording");

    let page = context.new_page().await.expect("Failed to create page");
    page.goto(&format!("{}/locators.html", server.url()), None)
        .await
        .expect("Failed to navigate");

    tracing
        .stop_har()
        .await
        .expect("Failed to stop HAR recording");

    // A HAR is a JSON document with `log.entries`. The navigated document must
    // appear among the recorded requests.
    let content = std::fs::read_to_string(&har_path).expect("HAR file should be written");
    let har: serde_json::Value = serde_json::from_str(&content).expect("HAR should be valid JSON");
    let entries = har["log"]["entries"]
        .as_array()
        .expect("HAR should have log.entries");
    assert!(
        !entries.is_empty(),
        "HAR should record at least the document request"
    );
    let urls: Vec<&str> = entries
        .iter()
        .filter_map(|e| e["request"]["url"].as_str())
        .collect();
    assert!(
        urls.iter().any(|u| u.contains("locators.html")),
        "HAR should include the navigated document, got {urls:?}"
    );

    let _ = std::fs::remove_file(&har_path);
    context.close().await.expect("Failed to close context");
    browser.close().await.expect("Failed to close browser");
    server.shutdown();
    drop(playwright);
}
